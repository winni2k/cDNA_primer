import os, re, sys, shutil, subprocess, datetime, time
import pdb

import numpy as np
import random
import miscBio
from Bio import SeqIO
from basQV import basQVcacher, basQVcacherSparse
from cPickle import *
from collections import defaultdict
import findECE
import init_ICE
import post_ICE


def eval_blasr_alignment(record, qver_get_func, sID_starts_with_c, qv_prob_threshold):
    """
    Takes a miscBio.BLASRRecord (blasr -m 5) and goes through the alignment string
    ex: |||**||||**|||*|*|
    to determine the sequence of 'M' (matches), 'S' (sub), 'I', 'D'

    qver_get_func --- could be either basQV.basQVcacher.get() or basQV.basQVcacher.get_smoothed()

    For any non-match, if either or both query/target's QV indicate that the event ('S', 'I', 'D')
    is expected (ex: insertion prob >= qv_prob_threshold), then it does not count as a penalty.

    Returns: cigar string, binary ECE array

    NOTE: long insertions/deletions are still a difficult problem because alignments can be arbitrary
          right now the quick solution is: use probqv get_smoothed
          however, with homopolymers, penalization can still happen unless I write code to check
          specifically for homopolymers (otherwise the cigar_str[-1]=='D' or 'I' sets in)
    """
    q_index = 0
    s_index = 0
    cigar_str = ''
    ece = np.zeros(len(record.alnStr), dtype=np.int) # binary array of 0|1 where 1 is a penalty
    #pdb.set_trace()
    for offset,nt_aln in enumerate(record.alnStr):
        if nt_aln=='|': # match
            cigar_str += 'M'
            q_index += 1
            s_index += 1
        elif record.qAln[offset]=='-': # deletion
            if cigar_str[-1]=='D' or (\
                qver_get_func(record.qID, 'DeletionQV', q_index+1) < qv_prob_threshold and \
               (sID_starts_with_c or qver_get_func(record.sID, 'InsertionQV', s_index) < qv_prob_threshold)):
                # case 1: last one was also a D  (so q_index did not advance)
                # case 2: both QVs were good yet still a non-match, penalty!
                ece[offset] = 1
            cigar_str += 'D'
            s_index += 1
        elif record.sAln[offset]=='-': # insertion
            if cigar_str[-1]=='I' or (\
                qver_get_func(record.qID, 'InsertionQV', q_index) < qv_prob_threshold and \
                (sID_starts_with_c or qver_get_func(record.sID, 'DeletionQV', s_index+1) < qv_prob_threshold)):
                # case 1: last one was also a I (so s_index did not advance)
                # case 2: both QVs were good yet still a no-match
                ece[offset] = 1
            cigar_str += 'I'
            q_index += 1
        else: # substitution
            cigar_str += 'S'
            if qver_get_func(record.qID, 'SubstitutionQV', q_index) < qv_prob_threshold and \
               (sID_starts_with_c or qver_get_func(record.sID, 'SubstitutionQV', s_index) < qv_prob_threshold):
                ece[offset] = 1
            q_index += 1
            s_index += 1
    #assert q_index == len(record.qAln) - record.qAln.count('-')
    #assert s_index == len(record.sAln) - record.sAln.count('-')
    return cigar_str, ece


def alignment_has_large_nonmatch(ece_arr, penalty, min_len):
    """
    penalty of (-)1: 50%
    penalty of (-)2: 66%
    penalty of (-)4: 80%
    penalty of (-)9: 90%

    Return True when alignment has large non-matches not explained by low base QVs
    (in other words, "reject" as an isoform hit and don't put in the same cluster)
    """
    ece_arr = ece_arr * (penalty + 1)
    s = [0] + list(ece_arr - penalty)
    return len(findECE.findECE(s, len(s), min_len, True)) > 0 # fix this later to something faster & better


cigar_rex = re.compile('(\d+)(\S)')
def unpack_cigar_string(cigar):
    """
    Unpack a cigar string (ex: 3M1I2D) 
    to a list (ex: ['M','M','M','I','D','D']        
    """
    result = []
    strlen = 0
    for m in cigar_rex.finditer(cigar):
        strlen += len(m.group(1)) + len(m.group(2))
        num, type = int(m.group(1)), m.group(2)
        result += [type] * num
    assert len(cigar) == strlen
    return result

def blasr_against_ref(output_filename, is_FL, sID_starts_with_c, qver_get_func, qv_prob_threshold=.1, ece_penalty=1, ece_min_len=20, same_strand_only=True):
    """

    Excluding criteria:
    (1) self hit
    (2) opposite strand hit  (should already be in the same orientation; can override with <same_strand_only> set to False)
    (3) less than 90% aligned or more than 50 bp missed

    qver_get_func --- should be basQV.basQVcacher.get() or .get_smoothed(), or can just pass in lambda (x, y): 1. to ignore QV
    """
    #subprocess.check_call("blasr {0} {1} -nproc 8 -m 5 -maxLCPLength 15 -out {2}".format(fasta_filename, ref_filename, output_filename), shell=True)
    for r in miscBio.BLASRm5Reader(output_filename):
        missed_q = r.qStart + r.qLength - r.qEnd
        missed_t = r.sStart + r.sLength - r.sEnd

        #print "mat:", nMatch, "mis:", nMismatch, "ins:", nIns, "del:", nDel, missed_q, missed_t
    
        if sID_starts_with_c:
            assert r.sID.startswith('c') # because all consensus should start with c<cluster_index>
            if r.sID.find('/') > 0:
                r.sID = r.sID.split('/')[0]
            if r.sID.endswith('_ref'): # probably c<cid>_ref
                cID = int(r.sID[1:-4])
            else:
                cID = int(r.sID[1:])
        else:
            cID = r.sID

        # self hit, useless!
        if cID == r.qID:
            yield r.qID, cID, None, None, None, None, None, None
            continue
        # HACK FOR MARILENA
        if r.identity < 90.: 
            yield r.qID, cID, None, None, None, None, None, None
            continue

        # opposite strand not allowed!
        if r.strand == '-' and same_strand_only:
            yield r.qID, cID, None, None, None, None, None, None
            continue
        
        # full-length case: allow up to 100bp of 5' not aligned and 30bp of 3' not aligned 
        # non-full-length case: not really tested...don't use
        if is_FL and (r.sStart > 100 or r.qStart > 100 or (r.sLength-r.sEnd > 30) or (r.qLength-r.qEnd > 30)):
            yield r.qID, cID, None, None, None, None, None, None
        else:
            cigar_str, ece_arr = eval_blasr_alignment(r, qver_get_func, sID_starts_with_c, qv_prob_threshold)
            if alignment_has_large_nonmatch(ece_arr, ece_penalty, ece_min_len):
                yield r.qID, cID, None, None, None, None, None, None
            else:
                yield r.qID, cID, r.qStart, r.qEnd, missed_q*1./r.qLength, missed_t*1./r.sLength, cigar_str, ece_arr

class fakeQVer:
    """
    Used by ProbFromModel to support the fake .get and .getsmoothed
    """            
    def get(self, x, y, z=None): return 0.
    def get_smoothed(self, x, y, z=None): return 0.

class ProbFromModel:
    def __init__(self, r_mis, r_ins, r_del):
        self.qver = fakeQVer()
        self.r_mis = r_mis
        self.r_ins = r_ins
        self.r_del = r_del
        self.r_mat = 1 - r_mis - r_ins - r_del
        assert self.r_mat > 0

    def add_seqs_from_fasta(self, fasta_filename, smooth=True):
        pass # dummy, nothing to do

    def remove_ids(self, ids):
        pass # dummy, nothing to do

    def get_qver_smoothed(self, *args):
        return 0.
    
    def get(self, x, y, z=None):
        return self.qver.get(x, y, z)

    def get_smoothed(self, x, y, z=None):
        return self.qver.get_smoothed(x,y,z)
        
    def calc_prob_from_aln(self, qID, qStart, qEnd, fakecigar):
        prob_mat = np.log(self.r_mat)
        prob_sub = np.log(self.r_mis)
        prob_ins = np.log(self.r_ins)
        prob_del = np.log(self.r_del)
        
        score = 0
        for x in fakecigar:
            if x == 'M': 
                score += prob_mat
            elif x == 'S':
                score += prob_sub
            elif x == 'I':
                score += prob_ins
            else: # x == 'D', don't advance qpos
                score += prob_del
        return score        
        
                 
        

class ProbFromQV:
    def __init__(self, input_fofn, fasta_filename=None, prob_threshold=.1, window_size=3):
        #self.qver = basQVcacherSparse(prob_threshold, window_size)
        self.qver = basQVcacher()
        self.input_fofn = input_fofn
        self.seqids = []
        self.prob_threshold = prob_threshold
        self.window_size = window_size
        self.full_prob = None
        
        with open(self.input_fofn) as f:
            for line in f:
                self.qver.add_bash5(line.strip())
                
        if fasta_filename is not None:
            self.add_seqs_from_fasta(fasta_filename)

        #self.qver.presmooth(self.seqids, self.window_size)

    def get_smoothed(self, qID, qvname, position=None):
        return self.qver.get_smoothed(qID, qvname, position)

    def get(self, qID, qvname, position=None):
        return self.qver.get(qID, qvname, position)

    def add_seqs_from_fasta(self, fasta_filename, smooth=True):
        with open(fasta_filename) as f:
            newids = [r.id for r in SeqIO.parse(f, 'fasta')]
        self.add_ids_from_fasta(newids, smooth)

    def add_ids_from_fasta(self, newids, smooth=True):
        self.qver.precache(newids)
        self.seqids += newids
        self.qver.presmooth(newids, self.window_size)
        #self.qver.remove_unsmoothed()
        
    def remove_ids(self, ids):
        for id in ids:
            self.seqids.remove(id)
            del self.qver.qv[id]
        
    def calc_prob_from_aln(self, qID, qStart, qEnd, fakecigar):
        """
        aln_record is a pysam.AlignedRead
        """    
        prob_sub = self.qver.get(qID, 'SubstitutionQV') + .0001
        prob_ins = self.qver.get(qID, 'InsertionQV')  + .0001
        prob_del = self.qver.get(qID, 'DeletionQV') + .0001 # using sparse matrix must make everything positive
        prob_mat = 1 - prob_sub - prob_ins - prob_del  # not really right, but should be ok for now...
        # sanity check...sometimes this can have < 0 prob, so assign it a small prob like 0.001
        ii = (prob_mat<=0)
        prob_mat[ii.nonzero()] = .001
        prob_sub = np.log(prob_sub)
        prob_ins = np.log(prob_ins)
        prob_del = np.log(prob_del)
        prob_mat = np.log(prob_mat)        
        
        one_three = np.log(1/3.)
        cur_q_pos = qStart
        score = 0
        for x in fakecigar:
            if x == 'M': 
                score += prob_mat[cur_q_pos] 
                cur_q_pos += 1
            elif x == 'S':
                score += prob_sub[cur_q_pos] + one_three
                cur_q_pos += 1
            elif x == 'I':
                score += prob_ins[cur_q_pos] + one_three
                cur_q_pos += 1
            else: # x == 'D', don't advance qpos
                score += prob_del[cur_q_pos]
        assert cur_q_pos == qEnd
        return score


class iCEC_iterative():
    """
    Expects that new fasta files will be gradually added
    """
    def __init__(self, fasta_filename, input_fofn, all_fasta_filename, uc=None, \
                 num_jobs=40, probQV=None, refs=None, d=None, use_parallel=True, is_FL=True, \
                 qv_prob_threshold=.1, ece_penalty=1, ece_min_len=20, maxScore=-1000, \
                 job_random_offset=random.randint(1, 9999), cpus=24):
        """
        all_fasta_filename --- this should be the *entire* fasta, not the one that we'll start with
        fasta_filename --- the current fasta filename containing all the "active" reads (reads that
                          are allowed to move to new clusters), 
                          usually called 'current.fasta' after 1 round
        input_fofn --- should be reads_of_insert.fofn these days
        
        uc --- the initial or current cluster assignment, dict of cid --> list of members
        refs ---  dict of cid --> fasta file containing the cluster consensus fasta
        d  --- dict of read id --> dict of cid:prob 

        qv_prob_threshold, ece_penalty, ece_min_len --- params for isoform accept/reject hit

        probQV --- ProbFromQV object, this is what takes up all the memory
        
        num_jobs --- number of qsub jobs to submit for gcon
        job_random_offset --- offset of qsub job id, important that this DOES NOT CONFLICT!

        """
        self.gcon_py = sanity_check_gcon()
        if use_parallel:
            sanity_check_sge(self.gcon_py)

        self.all_fasta_filename = all_fasta_filename
        self.fasta_filename = fasta_filename
        self.newids = set([r.id for r in SeqIO.parse(open(fasta_filename), 'fasta')])
        self.seq_dict = miscBio.FastaReader(all_fasta_filename)
        self.d = {} # probability dict, seqid --> cluster index i --> P(seq|C_i)
        self.refs = {} # cluster index --> gcon output consensus filename
        self.uc = {} # cluster index --> list of member seqids
        self.num_jobs = num_jobs
        self.changes = set() # list of cids that need to have gcon run (or re-run)
        self.rerun_gcon_size = 20 # size below which gcon must be re-run if changes were made
        self.log_f = open('ICE.log', 'a')
        self.use_parallel = use_parallel
        self.is_FL = is_FL

        self.nproc = cpus

        self.qv_prob_threshold = qv_prob_threshold
        self.ece_penalty = ece_penalty
        self.ece_min_len = ece_min_len
        
        self.unrun_cids = []

        self.job_random_offset = job_random_offset

        self.random_prob = 0.3 # random prob of putting a singleton into another cluster

        self.maxScore = maxScore

        self.log_f.write(str(datetime.datetime.now()) + '\n')
        self.log_f.write("ICE initiated.")

        if not os.path.exists("./tmp"):
            os.makedirs("./tmp")
        if not os.path.exists("./log"):
            os.makedirs("./log")
        if not os.path.exists("./scripts"):
            os.makedirs("./scripts")
        if not os.path.exists("./output"):
            os.makedirs("./output")

        self.input_fofn = input_fofn

        if probQV is not None:
            self.probQV = probQV
        else:
            self.probQV = ProbFromQV(input_fofn, self.fasta_filename)

        if uc is not None:
            self.uc = uc
        else:
            raise NotImplementedError, "I should add the init_ICE.init_cluster_by_clique() call here!"

        # only runs things in 'uc', so safe to run in init
        if refs is None:
            self.run_gcon_parallel(self.uc.keys())
        else:
            self.refs = refs
            
        #self.sanity_check_uc_refs()

        if d is None:
            self.init_d()
            self.calc_cluster_prob(force_calc=True)
        else:
            self.d = d


    def init_d(self):
        for cid, v in self.uc.iteritems():
            for qid in v:
                self.d[qid] = {}


    def sanity_check_uc_refs(self):
        """
        Check that all folders/files in refs exists
        For every cid in uc, there should be an entry in self.refs[cid]
        And there should be .tmp/c<cid>/in.fa and the refs file
        """
        if self.refs is None:
            return
        for cid in self.uc:
            assert cid in self.refs and os.path.exists(self.refs[cid])


    @staticmethod
    def from_pickle(pickle_filename, probQV, num_jobs):
        with open(pickle_filename) as h:
            a = load(h)
        uc = a['uc']
        refs = a['refs']
        d = a['d']
        all_fasta_filename = a['all_fasta_filename']
        maxScore = a['maxScore']
        ece_penalty = a['ece_penalty']
        ece_min_len = a['ece_min_len']
        job_random_offset = a['job_random_offset']
        # need to make current.fasta!!!
        newids = a['newids']
        with open(a['fasta_filename'], 'w') as f:
            for r in SeqIO.parse(open(all_fasta_filename), 'fasta'):
                if r.id in newids:
                    f.write(">{0}\n{1}\n".format(r.id, r.seq))
        obj = iCEC_iterative(a['fasta_filename'], a['input_fofn'], all_fasta_filename, probQV=probQV, uc=uc, refs=refs, d=d, ece_penalty=ece_penalty, ece_min_len=ece_min_len, maxScore=maxScore, num_jobs=num_jobs, job_random_offset=job_random_offset)
        obj.changes = a['changes']
        return obj

    @staticmethod
    def from_directories(fasta_filename, all_fasta_filename, input_fofn, probQV, d, ece_penalty, ece_min_len, num_jobs):
        """
        Crawl ./tmp/ directory to get refs and uc
        TODO: I have not used this in a while. PROBABLY BUGGY.
        """
        refs = {}
        uc = {}
        for x in os.listdir('./tmp'):
            d1 = os.path.join('./tmp', x)
            if os.path.isdir(d1) and x.startswith('c'):
                cid = int(x[1:])
                print >> sys.stderr, "reading directory", cid
                file1 = os.path.join(d1, 'g_consensus.fa')
                file2 = os.path.join(d1, 'g_consensus_ref.fa')
                file3 = os.path.join(d1, 'in.fa.1stseq.fa')
                if os.path.exists(file1):
                    refs[cid] = file1
                elif os.path.exists(file2):
                    refs[cid] = file2
                else:
                    assert os.path.exists(file3)
                    refs[cid] = file3
                uc[cid] = []
                for r in SeqIO.parse(open(os.path.join(d1, 'in.fa')), 'fasta'):
                    uc[cid].append(r.id)
        return iCEC_iterative(fasta_filename, input_fofn, None, all_fasta_filename, probQV=probQV, uc=uc, refs=refs, d=d, ece_penalty=ece_penalty, ece_min_len=ece_min_len, num_jobs=num_jobs)


    def write_final_consensus(self):
        """
        Write output to final.consensus.fa
        """
        self.write_consensus(os.path.join("output", "final.consensus.fa"))

    def write_consensus(self, fasta_filename):
        """
        Write output to final.consensus.fan
        Sequence ID format
        >c<cid>/abundance/length
        """
        with open(fasta_filename, 'w') as f:
            for cid,filename in self.refs.iteritems():
                assert cid in self.uc
                r = SeqIO.read(open(filename), 'fasta')
                newid = "c{cid}/{ab}/{le}".format(cid=cid, ab=len(self.uc[cid]), le=len(r.seq))
                f.write(">{0}\n{1}\n".format(newid, r.seq))

    def write_final_pickle(self):
        self.write_pickle(os.path.join("output", 'final.pickle'))

    def write_pickle(self, pickle_filename):
        with open(pickle_filename, 'w') as f:
            d = {'uc':self.uc, 'd':self.d, 'refs':self.refs, \
                'input_fofn':self.input_fofn, \
                'fasta_filename':self.fasta_filename}
            d['ece_penalty'] = self.ece_penalty
            d['ece_min_len'] = self.ece_min_len
            d['maxScore'] = self.maxScore
            d['newids'] = self.newids
            d['all_fasta_filename'] = self.all_fasta_filename
            d['job_random_offset'] = self.job_random_offset
            d['changes'] = self.changes
            dump(d, f)

    def make_new_cluster(self):
        best_i = max(self.uc.keys()) + 1
        self.uc[best_i] = []
        return best_i

    def remove_from_cluster(self, qID, from_i):
        self.uc[from_i].remove(qID)
        self.changes.add(from_i)
        if len(self.uc[from_i]) == 0:
            self.delete_cluster(from_i)

    def delete_cluster(self, from_i):
        """
        1) delete it from self.uc
        2) delete all related entries from self.d
        3) delete self.refs
        4) remove the directory
        5) remove from self.changes (if there)
        """
        del self.uc[from_i]
        for k in self.d:
            if from_i in self.d[k]: del self.d[k][from_i]
        del self.refs[from_i]
        dirname = os.path.join("./tmp/", 'c'+str(from_i))
        shutil.rmtree(dirname)
        if from_i in self.changes: self.changes.remove(from_i)

    def no_moves_possible(self):
        for cid, members in self.uc.iteritems():
            if len(members) <= 2: # match singleton criterion here
                for x in members:
                    if len(self.d[x]) > 1: return False
            else:
                for x in members:
                    if cid not in self.d[x]:
                        return False
                    if self.d[x][cid] != max(self.d[x].itervalues()):
                        return False
        return True

    def run_gcon_parallel(self, cids):
        """
        A wrapper for run_gcon_parallel_helper

        In case some gcon jobs fail (qsub failure), it should pick it up and re-run them
        """
        self.unrun_cids = []
        self.run_gcon_parallel_helper(cids)
        while len(self.unrun_cids) > 0:
            print >> sys.stderr, "NEED to RE-RUN gcon for {0} clusters!".format(len(self.unrun_cids))
            _cids = list(self.unrun_cids)
            self.unrun_cids = []
            self.run_gcon_parallel_helper(_cids)

    def run_gcon_parallel_helper(self, cids):
        """
        Run gcon on all clusters in <cids>
        Parallelize gcon calls to <self.num_jobs> nodes

        For each cid in <cids>,
        (1) ./tmp/c<cid>/in.fa is created
        (2) run gcon on <cid> only if the size > 2
        """
        # calculate effective chunk size
        effective_cids = filter(lambda cid: len(self.uc[cid])>2, cids)
        count_jobs = len(effective_cids)
        chunk_size = count_jobs/self.num_jobs + (count_jobs%self.num_jobs>0)

        job_sh_dict = {} # job_i --> file descriptor
        if count_jobs > 0:
            #ToDo: distribute jobs evenly (must look ahead at cluster sizes)
            for job_i in xrange((count_jobs/chunk_size)+(count_jobs%chunk_size>0)):
                f = open("./scripts/gcon_job_{0}.sh".format(job_i), 'w')
                f.write("#!/bin/bash\n")
                f.write(". {0}/bin/activate\n".format(os.environ['VIRTUAL_ENV']))
                job_sh_dict[job_i] = f

        effective_i = 0
        for cid in cids:
            dirname = os.path.join("./tmp/", 'c'+str(cid))
            if os.path.exists(dirname):
                #print >> sys.stderr, "cleaning", dirname
                shutil.rmtree(dirname)
            os.makedirs(dirname)
            in_fa_filename = self.write_in_fasta(cid)

            if len(self.uc[cid]) <= 2: # don't even bother running gcon
                pass # for now do nothing and let the else statement below take care of it
            else:
                job_i = effective_i / chunk_size
                job_sh_dict[job_i].write("python {script} d {input} --disable_hp_correction --min_cov 1 -d ./tmp/c{i} --cname c{i}\n".format(script=self.gcon_py,i=cid,input=in_fa_filename))
                effective_i += 1

        if effective_i > 0:
            if self.use_parallel:
                job_list = ''
                for job_i,f in job_sh_dict.iteritems():
                    f.close()
                    subprocess.check_call("qsub -pe smp 1 -cwd -S /bin/bash -e /dev/null -o /dev/null  -N j{0} {1}".format(job_i+self.job_random_offset,f.name), shell=True)
                    job_list += 'j' + str(job_i+self.job_random_offset) + ','
                with open("./scripts/gcon_done.sh", 'w') as f:
                    f.write("touch ./scripts/ALOHA\n")
                print >> sys.stderr, "waiting for gcon jobs to finish"
                subprocess.check_call("qsub -sync y -pe smp 1 -cwd -S /bin/bash -e /dev/null -o /dev/null -hold_jid {0} ./scripts/gcon_done.sh".format(job_list[:-1]), shell=True)
            else:
                for job_i,f in job_sh_dict.iteritems():
                    f.close()
                    print >> sys.stderr, "running script", f.name
                    subprocess.check_call("bash " + f.name, shell=True)

        for cid in cids:
            self.refs[cid] = self.choose_ref_file(cid)

        ## now must clean up the scripts?
        for f in job_sh_dict.itervalues():
            os.remove(f.name)

        if effective_i > 0 and self.use_parallel:
            os.remove("./scripts/gcon_done.sh")
            os.remove("./scripts/ALOHA")

    def choose_ref_file(self, cid):
        """
        Return g_consensus.fa if not empty (i.e. gcon succeeded)
        Otherwise return g_consensus_ref.fa if not empty
        Finally, just randomly pick the 1st sequence as cluster representative
        """
        dirname = os.path.join("./tmp/", 'c'+str(cid))
        cons = os.path.join(dirname, "g_consensus.fa")
        cons_ref = os.path.join(dirname, "g_consensus_ref.fa")
        if os.path.exists(cons) and len(SeqIO.read(open(cons),'fasta')) > 0:
            return cons
        elif os.path.exists(cons_ref) and len(SeqIO.read(open(cons_ref),'fasta')) > 0:
            return cons_ref
        elif len(self.uc[cid]) > 3: # should have run but did not, count as must re-run!!!
            self.unrun_cids.append(cid)
        else: # pick the 1st sequence
            rname = os.path.join(dirname, 'in.fa.1stseq.fa')
            with open(rname, 'w') as h:
                h.write(">c{0}\n{1}\n".format(cid, self.seq_dict[self.uc[cid][0]].seq))
            return rname

    def clean_prob_for_cids(self, cids):
        """
        Takes |qIDs| x |cIds| time....

        For every d[qID][cID] such that qID is in self.newids and cID is in cids, delete it
        """
        for qid in self.newids:
            #print >> sys.stderr, "cleaning for", qid
            for cid in set(cids).intersection(self.d[qid]):
                del self.d[qid][cid]
                
    def final_round_before_freeze(self, min_cluster_size):
        """
        Only do 1 kind of move: for any qID where self.d[qID][cID] is not the best one
        remove it and put it in the next batch, i.e.
        --- remove it from icec.uc (delete the cluster if it becomes empty)
        --- delete entry icec.d[qID]

        then, run gcon on the changed clusters
        
        ToDo: to do this iteratively would require actively removing qids from self.fasta_filename
              otherwise self.calc_cluster_prob() will break. too lazy now. just run once.
        """
        self.removed_qids = set()
        self.changes = set()

        cids = self.uc.keys()
        for cid in cids:
            n = len(self.uc[cid])
            for qid in self.uc[cid]:
                if n < min_cluster_size or cid not in self.d[qid] or self.d[qid][cid]!=max(self.d[qid].itervalues()):
                    print >> sys.stderr, "remove {0} (from {1}) because {2}".format(qid, cid, self.d[qid])
                    del self.d[qid]
                    self.remove_from_cluster(qid, cid)
                    if cid in self.uc and len(self.uc[cid]) < self.rerun_gcon_size:
                        self.changes.add(cid)
                    self.removed_qids.add(qid)
        self.run_gcon_parallel(self.changes)


    def write_in_fasta(self, cid):
        """
        Write the ./tmp/c<cid>/in.fa
        """
        in_filename = os.path.join('tmp', 'c'+str(cid), 'in.fa')
        with open(in_filename, 'w') as f:
            for seqid in self.uc[cid]:
                f.write(">{0}\n{1}\n".format(seqid, self.seq_dict[seqid].seq))
        return in_filename


    def add_seq_to_cluster(self):
        """
        After running blasr of newids (current batch) against existing clusters,
        (1) for all ids that have a non-empty prob dict, add to the best cluster
        (2) otherwise, put in orphan group (to run clique finding later)
        """
        orphan = []
        for id in self.newids:
            if len(self.d[id]) == 0: # no match to existing cluster
                orphan.append(id)
            else:
                best = self.d[id].items()
                best.sort(key=lambda x: x[1], reverse=True)
                cid = best[0][0]
                r = self.seq_dict[id]
                print >> sys.stderr, "adding {0} to c{1}".format(id, cid)
                if len(self.uc[cid]) < self.rerun_gcon_size:
                    self.write_in_fasta(cid) # I don't think this is really needed since when run_gcon_parallel is called later it regenerates the in.fa along with the whole folder
                    self.changes.add(cid)
                self.uc[cid].append(r.id)
        return orphan


    def add_uc(self, uc):
        """
        Add new clusters (probably after running clique finder)
        """
        i = max(self.uc) + 1
        for k,v in uc.iteritems():
            cid = k + i
            self.uc[cid] = v
            self.changes.add(cid) # even if it's a size-1/2 cluster, it still needs to be in changes for the dir to be created


    def freeze_d(self, cids=None):
        """
        For any ids not in the current batch set self.d[qID][cID] = 0
        so it will never be kicked out of the cluster
        NOTE: this needs to be recalled every time calc_prob is called because it resets certain self.d's
        """
        if cids is not None:
            for cid in cids:
                if len(self.uc[cid]) < self.rerun_gcon_size: continue # no way it's needed
                for qid in set(self.uc[cid]).difference(self.newids):
                    self.d[qid] = {cid: -0}                    
        else:
            for cid, qids in self.uc.iteritems():
                if len(self.uc[cid]) < self.rerun_gcon_size: continue # no way it's needed
                for qid in set(qids).difference(self.newids):
                    self.d[qid] = {cid: -0}


    #def merge_ij_nogcon(self, i, j):
    #    k = self.make_new_cluster()
    #    self.uc[k] = self.uc[i] + self.uc[j]
    #    self.delete_cluster(i)
    #    self.delete_cluster(j)
    #    self.freeze_d([k])
    #    self.changes.add(k)


    def calc_cluster_prob(self, force_calc=False):
        """
        Dump all consensus file to ref_consensus.fa --> get SA
        --> run self BLASR
        """
        # make the consensus file & SA 
        _todo = set(self.uc.keys()) if force_calc else self.changes
        if len(_todo) == 0: return
        with open('ref_consensus.fa', 'w') as f:
            for cid in _todo:
                r = SeqIO.read(open(self.refs[cid]), 'fasta')
                f.write(">{0}\n{1}\n".format(r.id, r.seq))

        cmd = "sawriter {0}.sa {0} -blt 8 -welter".format(f.name)
        print >> sys.stderr, "CMD:", cmd
        subprocess.check_call(cmd, shell=True)

        if os.path.exists(f.name + '.blasr'):
            os.remove(f.name + '.blasr')
        cmd = "blasr {0} {1} -m 5 -bestn 10 -nCandidates 10 -sa {1}.sa -maxLCPLength 15 -nproc {3} -maxScore {2} -out {1}.blasr".format(self.fasta_filename, f.name, self.maxScore, self.nproc)
        print >> sys.stderr, "CMD:", cmd
        if subprocess.check_call(cmd, shell=True)!=0:
            raise Exception, "trouble running command", cmd

        self.clean_prob_for_cids(_todo)
        self.g(f.name+'.blasr')


    def g(self, output_filename):
        """
        The meat of processing a BLASR output
        Fills in the self.d
        (REMEMBER to pre-clean the self.d)
        """
        for qID, cID, qStart, qEnd, missed_q, missed_t, fakecigar, ece_arr in blasr_against_ref(output_filename, is_FL=self.is_FL, sID_starts_with_c=True, qver_get_func=self.probQV.get_smoothed, qv_prob_threshold=self.qv_prob_threshold, ece_penalty=self.ece_penalty, ece_min_len=self.ece_min_len):
            if qID not in self.d: self.d[qID] = {}
            if fakecigar is not None:
                self.d[qID][cID] = self.probQV.calc_prob_from_aln(qID, qStart, qEnd, fakecigar)


    def run_til_end(self, max_iter=99):
        """
        This should only be run on the first round. Before add_new_batch() is ever called.

        (1) dump current stuff to tmp pickle
        (2) reassign clusters as needed (call self.onemove())
        (3) re-cluster the orphans
        """
        no_change_count = 0
        iter_count = 1
        while no_change_count < 10 and iter_count <= max_iter:
            iter_count += 1
            prefix = os.path.join('output', 'tmp'+str(int(time.time())))
            self.write_pickle(prefix + '.pickle')
            orphans = self.onemove()
            if len(orphans) > 0:            
                with open('tmp.orphan.fa','w') as f:
                    for id in orphans:
                        f.write(">{0}\n{1}\n".format(id, self.seq_dict[id].seq))
                try:
                    os.remove('tmp.orphan.fa.self.blasr')
                except:
                    pass
                uc = init_ICE.init_cluster_by_clique('tmp.orphan.fa', self.probQV.get_smoothed, nproc=self.nproc, ece_penalty=self.ece_penalty, ece_min_len=self.ece_min_len, maxScore=self.maxScore)                
                self.add_uc(uc)

            # record the current gcon consensus
            self.current_gcon_seq_in_changes = {}
            for cid in self.changes:
                if cid in self.refs:
                    with open(self.refs[cid]) as h:
                        self.current_gcon_seq_in_changes[cid] = SeqIO.read(h, 'fasta').seq.tostring()
            self.run_gcon_parallel(self.changes)
            # remove from self.changes ones that did not change
            _cids = set(self.changes)
            for cid in _cids:
                if cid in self.current_gcon_seq_in_changes:
                    with open(self.refs[cid]) as h:
                        seq = SeqIO.read(h, 'fasta').seq.tostring()
                        if seq == self.current_gcon_seq_in_changes[cid]:
                            print >> sys.stderr, "REMOVING {0} from self.changes because no gcon change".format(cid)
                            self.changes.remove(cid)
            self.calc_cluster_prob()
            self.freeze_d()
            # see if there are more moves possible
            if self.no_moves_possible():
                print >> sys.stderr, "No more moves possible. Done!"
                break
            no_change_count += len(self.changes) == 0
        #self.write_final_consensus()
        #self.write_final_pickle()

    def onemove(self):
        """
        (1) if has a better cluster, move to it
        (2) if no bette cluster, move it to orphan group
        """
        self.changes = set() # always clean up changes first
        orphan = []
        qid_to_cid = {} # qID --> cluster index
        # make cluster_dict
        for i,cluster in self.uc.iteritems():
            for qID in cluster: qid_to_cid[qID] = i
        
        for qID in self.d:
            old_i = qid_to_cid[qID]
            x = self.d[qID].items()
            if len(x) == 0: # no best! move it to the orphan group
                self.remove_from_cluster(qID, old_i)
                orphan.append(qID)
            else:
                x.sort(key=lambda p: p[1], reverse=True)
                best_i, best_i_prob = x[0][0], x[0][1]
                if best_i!=qid_to_cid[qID]: # moving assignment from old_i to best_i
                    print >> sys.stderr, "best for {0} is {1},{2} (currently: {3},{4}".format(qID,best_i,best_i_prob,old_i,self.d[qID][old_i] if old_i in self.d[qID] else 'None')
                    self.log_f.write("best for {0} is {1},{2} (currently: {3},{4}\n".format(qID,best_i,best_i_prob,old_i,self.d[qID][old_i] if old_i in self.d[qID] else 'None'))
                    # move qID to best_i
                    self.uc[best_i].append(qID)
                    # ToDo: make more flexible
                    # changes were made to from_i and best_i
                    # only re-run gcon if the clusters are small
                    if len(self.uc[best_i]) < self.rerun_gcon_size:
                        self.changes.add(best_i)
                    if len(self.uc[old_i]) < self.rerun_gcon_size:
                        self.changes.add(old_i)
                    self.remove_from_cluster(qID, old_i)              
                else:
                    # --------------------------
                    # singletons always have best prob as it self, so treat specially
                    # if there is another cluster with no-zero prob
                    # move to it with some probability   
                    # NOTE: here singleton is anything <= 2 (match what my criterion
                    # is in run_gcon_parallel)
                    # --------------------------
                    if len(self.uc[old_i]) <= 2:
                        x = filter(lambda (a,b): a!=old_i, x)
                        if len(x)>0 and random.random() <= self.random_prob: # right now hard-code to 30% prob
                            best_i, best_i_prob = x[0][0], x[0][1]
                            print >> sys.stderr, "randomly moving {0} from {1} to {2}".format(qID, old_i, best_i)
                            self.log_f.write("randomly moving {0} from {1} to {2}\n".format(qID, old_i, best_i))
                            self.uc[best_i].append(qID)
                            if len(self.uc[best_i]) < self.rerun_gcon_size:
                                self.changes.add(best_i)
                            self.changes.add(old_i)
                            self.remove_from_cluster(qID, old_i)
        return orphan
                        
    def add_new_batch(self, batch_filename):
        # sanity check: the file should exist & it should not already exist
        assert os.path.exists(batch_filename)
        for r in SeqIO.parse(open(batch_filename), 'fasta'): assert r.id not in self.d

        # after this step:
        # self.removed_qids contains ids that were removed from icec.uc/icec.d
        # self.fasta_filename is still pointing to the current version, not new batch fasta                 
        self.final_round_before_freeze(0)

        # after this step:
        # active_ids temporarily hold IDs that are still in self.uc/self.d but from small clusters
        # later will append them to the latest fasta file so they still can move around
        self.active_ids = set()
        for cid, ids in self.uc.iteritems():
            if len(ids) >= self.rerun_gcon_size:
                print >> sys.stderr, "removing from probQV all members of {0}".format(cid) # if not already removed
                self.probQV.remove_ids(self.newids.intersection(ids))
            else:
                self.active_ids.update(ids)
                
        # after this step:
        # latest fasta file is changed to {new batch} + {any id that was removed from final round}                    
        self.fasta_filename = "current.fasta"
        subprocess.check_call("cp {0} current.fasta".format(batch_filename), shell=True)
        with open(self.fasta_filename, 'a') as f:
            for id in self.removed_qids:
                f.write(">{0}\n{1}\n".format(id, self.seq_dict[id].seq))
        
        # after this step:
        # setting newids =  {new batch} + {any id removed from final round}
        # self.d is initialized for everything in newids
        self.newids = set()
        for r in SeqIO.parse(open(self.fasta_filename),'fasta'):
            self.d[r.id] = {}
            self.newids.add(r.id)


        # adding {new batch} to probQV
        # now probQV contains {new batch} + {any id removed from final round} + {active ids}
        self.probQV.add_seqs_from_fasta(batch_filename, smooth=True) # only ids from new batch are not already in probQV
        
        self.calc_cluster_prob(True)
        orphans = self.add_seq_to_cluster()
        with open(self.fasta_filename + '.orphan.fa','w') as f:
            for id in orphans:
                f.write(">{0}\n{1}\n".format(id, self.seq_dict[id].seq))
        
        if os.path.exists(self.fasta_filename + '.orphan.fa.self.blasr'):
            os.remove(self.fasta_filename + '.orphan.fa.self.blasr') # must clean it in case it already exists
        uc = init_ICE.init_cluster_by_clique(self.fasta_filename + '.orphan.fa', self.probQV.get_smoothed, nproc=self.nproc, bestn=200, ece_penalty=self.ece_penalty, ece_min_len=self.ece_min_len, maxScore=self.maxScore)
        self.add_uc(uc)
        self.run_gcon_parallel(self.changes)        
        
        # wait until now to incorporate active_ids to save unncessary BLASR-ing on them since their icec.d would thus far remain the same unless it's in icec.changes
        # adding {active ids} to current fasta file
        # now fasta file contains {new batch} + {any id removed from final round} + {active ids}
        # which is consistent with self.newids and self.probQV
        f = open(self.fasta_filename, 'a')
        for id in self.active_ids:
            f.write(">{0}\n{1}\n".format(id, self.seq_dict[id].seq))
        f.close() 
        self.newids.update(self.active_ids)

        # sanity check!
        assert self.check_probQV_newid_consistency()
        
        # update prob for self.newids VS {all changed clusters}
        self.calc_cluster_prob()
        #self.freeze_d()


    def check_probQV_newid_consistency(self):
        """
        Check that
        self.fasta_filename agrees with self.newids agrees with self.probQV
        """
        all_good = True
        for r in SeqIO.parse(open(self.fasta_filename), 'fasta'):
            if r.id not in self.newids:
                self.newids.add(r.id)
                has_err = False
                print >> sys.stderr, "ERROR: {0} should be in newids but not. Adding it!".format(r.id)
            try:
                self.probQV.get_smoothed(r.id, 'DeletionQV')
            except KeyError:
                has_err = False
                self.probQV.add_ids_from_fasta([r.id], True)
                print >> sys.stderr, "ERROR: {0} should be in probQV but not. Adding it!".format(r.id)
        return all_good


    def run_for_new_batch(self):
        self.freeze_d() # run it first in case I forgot
        self.run_til_end(1)
        self.freeze_d()


def sanity_check_gcon():  
    d = os.path.dirname(os.path.realpath(__file__))
    p_filename = os.path.join(d, 'gcon_Liztools.py')
    if not os.path.exists(p_filename):
        print >> sys.stderr, "Expected to have file {0} but not found. Abort".format(p_filenmae)
        sys.exit(-1)
        
    return p_filename


def sanity_check_sge(script_path):
    with open('in.fa', 'w') as f:
        f.write(GCON_IN_FA)
    with open('out.fa', 'w') as f:
        f.write(GCON_OUT_FA)

    with open('test.sh', 'w') as f:
        f.write("#!/bin/bash\n")
        f.write(". {0}/bin/activate\n".format(os.environ['VIRTUAL_ENV']))
        f.write("python {script} d in.fa --disable_hp_correction --min_cov 1 --cname c1\n".format(script=script_path))
        
    cmd = "qsub -sync y -cwd -pe smp 8 -S /bin/bash test.sh"
    print >> sys.stderr, "Submitting cmd: ", cmd
    subprocess.check_call(cmd, shell=True)
    
    if subprocess.check_output("diff g_consensus.fa out.fa", shell=True)!='':
        print >> sys.stderr, "Trouble running qsub or output is not as expected ({0} and {1} must agree). Abort!".format(output1, output2)
        sys.exit(-1)
        
    subprocess.check_call("rm -rf test.sh* in.fa* g_consensus*", shell=True)    
    print >> sys.stderr, "SGE and gcon check passed."


def check_cluster_sanity(icec, skip_dir_test=True):
    _membership = {}
    for cid,members in icec.uc.iteritems():
        for x in members:
            assert x not in _membership
            _membership[x] = cid
        if cid not in icec.refs or len(icec.refs[cid])==0:
            print "ref for {0} does not exist!".format(cid)
        elif not skip_dir_test:# or random.random() <= .01:
            print >> sys.stderr, "randomly checking", cid
            seqids = set(line.strip()[1:] for line in os.popen("grep \">\" " + os.path.join('tmp','c'+str(cid),'in.fa')))
            assert seqids == set(members)
    for x in icec.d:
        if len(icec.d[x])==1 and icec.d[x].values()[0]==0:
            cid = icec.d[x].keys()[0]
            assert len(icec.uc[cid]) >= icec.rerun_gcon_size


def keep_adding_files(icec, sizes, files):
    """
    Iteratively add new files for <icec>
    (1) merge for at most 3 rounds
    (2) add new batch
    (3) cluster reassignments (run_for_new_batch)
    """
    for file in files:
        run_post_ICE_merging(icec, 'output/tmp', 3)
        icec.add_new_batch(file)
        check_cluster_sanity(icec)
        for i in xrange(5):
            icec.run_for_new_batch()
            sizes.append(len(icec.uc))
        icec.write_pickle('output/upto_'+file+'.pickle')
        icec.write_consensus('output/upto_'+file+'.consensus.fa')


def final_rounds(icec, sizes):
    """
    This does not add new files, instead it just iterates over merging & reassignment
    """
    raise NotImplementedError



def run_post_ICE_merging(icec, out_prefix, max_iter):
    """
    (1) write pickle/consensus file
    (2) find mergeable clusters
    (3) run gcon on all merged clusters
    """
    consensus_filename = out_prefix + '.consensus.fa'
    pickle_filename = out_prefix + '.pickle'
    icec._changes = set(icec.changes) # this is just back up for debugging purpose
    for i in xrange(max_iter):
        icec.changes = set()
        print >> sys.stderr, "writing pickle file", pickle_filename
        icec.write_pickle(pickle_filename)
        print >> sys.stderr, "writing consensus file", consensus_filename
        icec.write_consensus(consensus_filename)
        fname = consensus_filename
        iter = post_ICE.find_mergeable_consensus(fname, maxScore=icec.maxScore, ece_penalty=icec.ece_penalty, ece_min_len=icec.ece_min_len, nproc=icec.nproc)
        for r in iter:
            post_ICE.do_icec_merge_nogcon(icec, r)
        if len(icec.changes) == 0:
            print >> sys.stderr, "No more merges, break!"
            break
        icec.run_gcon_parallel(icec.changes)
        icec.calc_cluster_prob()
        icec.freeze_d()


GCON_OUT_FA=">c1\nACGTCGGACAACATAGGCACAGGCACTCAGGGTACGTAAGACGAACATGAGCACGCAGGGGCAGTCATCACTCTAGCACCCACTTCGTTTCCcTTTTCCCACGTCTTGCTCATCCCCTTCAACGACGATGAAGTCTGTGTTTGTTTCCCTCGCGTCTGTGTCCCTCTTCGCGGCTGGCGTCCTTGGCCAGTCTCTCCAGATCAACACGCCGGCCAGCGCTGTTGAGTGCCAACCGACTCTCCTCTCCTGGAGCGGTGGAACCCCCCGTACTTCTTGAGCGTCCTCCCGGTAACTCGCCTTCGTCGCCCGCCCTCCAGGACCTCGGCACTCAGACCGGCACCTCGTTCACCTGGTCCACCAACATCACCGCCGATACCTCTGTTGGCCTGACCCTCAAGGACAGCACTGgTGCCATTGCCCAGAGCGCAGCATTCACGATCCAGGCCGGCTCTTCCTCCTGCATTGGTGGATCCAGTTCCTCCACCGCCGCGGGTTCGTCAGGTTCGACGAGTGCCACGACGTCGGCAGGTACTACATCCTCTTCTTCATCGTCTGCGGCCGCAACCACGTCATCTGCCTCGAAAGCGTCTTCAGCGTCAGTGACCACTTCTTCAGCTGCAGGATCGGGTAGCTCCTCTGCCTCCAAGACTGGCTCCAGTACCTCGGCTGCCGCCAGCTCCTCTGGCAGCGCTTCGTCGAGCAGCTCTGCCGGCTTCACCAACGGCGTCAACTACGGTGTCGCCGCCGTCGCCGCCGCCGTTTTCGCCATGCTCGGATAAGCGGTTGCATGTTTTGAAAAGGTGGATGGTTTCGTTGGTTGCGTCCACACCCTCCCcATCCGCTCTTTGTTCCGTTTCTTTCTGCTCGCCCTCGATAATCAAACGGACCATTTTTTCACACATGCGCTTTTTACAGCCGCTGCCCTCGCTCGCTCCTCCGGTTACACTCAACCCTCAACACGTAGTGTCTCCGCTCTCGCAGTACATATATCCATTAATACCTGCCGTTTTGATTCCGTACTTTCTCAATACGCAGTCACACTTTCTTCTACCTCAGAGTCTGTTGCCTAGTGACACTTCTTTATCTGCTCTTGCTTCACCTTGTTGCGCTTCGATCTTGGATTCATCCCTCCCGCCTGGAGACGTTGTATGTAGCGCTTCCACCGTGGTGTACAGACGATTACTTCACGATCCCAACGACTATCGAGGTTCTTTTTCTTTGGT\n"

GCON_IN_FA=\
""">m120411_073645_00123_c100307122550000001523011208061264_s2_p0/60255/1068_2337
ACGTCGGACAACATAGGCACAGGCACTCAGGGTACGTAAGACGAACATGAGCACGCAGGGGCAGTCATCACTCTAGCACTCGCACGTTCGTTTCCCTTTTCCCACGTCTTTGCTCATCCCCTTCAACGACGATAAGTCTGGTTTGTTTCCTCCGCGTTGTGTCCCTCTTCGCGGCTGGCGTCCTTGGGTACAGTCCTCTCCAGATCAATAACGCCGGCCAGCGCTGTTGAGTGCCACCGACTCCTCCTCTCCCTGGATCGGTGGAACCCCCCGTACTTCCTTGAGCGTCCTCCCCCGGTAACTCAGCCTTCAGTCGCCCGCCCCTCCCAGGACCTCAGGCACTCAGACCGGCACCGTCGTTCACCTGTCCACCAACATCACCGCCGATACCTCTGTTGGCCTGACCCTCAAGGACGGCACTGTTGCCATTTGCTCCAGAGCGCAGCATGCACGATCCAGGCCGGCTCTTCCTCCTGCATTGGTGATCCAGTTCCTCCACCGCGCGGGGTCCGTCCAGCGTTCGACGAGTGCCACCGCACGTCGGTCAAGGTACTGACATCCTCTTCTTCCATCGTCTGCGGCCGCAACCACGTCATCTTGCCTCGAAAGCGTCTTCCAGCGTCAGTACCACTTCCTTCAAGCTGCGGATCGGGGTGCTCCTCTGCCATCCAAGACTGGTCCAGTACCTCCGGCATGCCGCCAGCATCCTCTGTCAGCGAAGGGCTTCGTAAAGAGCAGCTCTGGCCGGCCTTCACCACGCGTCAACTACGTTCGCCCGCCCGTCGCGCCGCCGTTTCGCCATGCTCGGATAAGCGGGTTGCCATGTTTTGAAAAGCGTGGGTATGGTTTCGCTTGTTGCGTCCAACACCCTCCCCATCCGCTAATTTGTTCCGTTTCTTTCTTTGCTCGCCCCTCGGATAATCAAACGGACCATTTTTTCAACATGCGCTTTTTACCAGCCGCTGCCTCGCTCGCTCTCCGTTAACACGTCAAGCGCTCAACACGTAGTGTCTCCGCTCCCGGCATACATATATCCATTAATACCCTGCCGTTTTTGATTCCGTAACTTTCCCAATACGCATCACCTTTCTTCTACCTCAGAGTCTGTGCTAGTTGACACTTTCTTTAATCTGCTCTTGCTTCACCTTGTTGCGCTTCGATCTTGATTTCATCCCTCCCGCCTGGGAGACGTTGTATGTAGCGCTTCCACCGTGGTGACAGACGATTACTTCCGATCCCAACGACTAATCGAAGTTCTTTTTCTTTGGT
>m120107_231407_richard_c100267182550000001523003605171272_s1_p0/51294/4045_5265
GTGGCAGGCCCATCACTCTAGCACCCACTTCGTTCCCTTTCCCCACGTCTTGCTCATCCCTTCACGGACGAGGAAGTCGGTGTTTGTTTCCCCCGCGTCTGGCTCCTCTTCGCGGCTGGCGTCTTGCCAGTCTCTCCAAAGGAATTTCAACACGCCGGCCAGCGCTGTTGAGTGGCCAACCGACTCTCCTCTCCTGGAGCGGTGGATACCCCGTACTTCCTTGAGGCGTCCTCCCGGTAACATCGCCTCGTCGCCCGCCCTCACAGGACCTCGGCACTCAGACCGCCACCTCGTCAACCTGGTACCAACATCCCCGCCGAGACCTGTCTGTGGGCCTGACCTGCAAGGACAGCACTGTGCATTGGCCCAGAGGCGCAGCATTCACGATCCAGTGCCCGGCTCTTCCCTCCTGCATTGGTGATCCCAGTTCCTCCACCCGCCGGCGGGTGTCAGGTTCGACGAGTGCCACGACCGTCGGCAGGTACTACATCCTCTTCTTCATCGTCCGCGTCCGCAACCACGTCATCTGCCCGTCGAAAGCGTCTTCAGCGTCAGTGACCACTTCTTTCAGCGCTGCAGGATCGGCGTATGCTGCCTCTGCCTCCAAGACTGGCTCCAGTAAGCTACTCGCTGCCCGCCACCTCTGCTGGCAGGCGCTTCGTCGAGCAGCTCTGCCGGCTTCCACCCACACGGCCGTCACTACGCGTGTCGCGCGCCGTCGCGCCGCCTGTTTCGCCATGCTCGGAATTAAGCCGGCTGCTGCATTGCCCTTTTCGCAACAAACGTCATGGTTTCTTCGTTCCGGTTGCGTCCACACCCTCCATGCCCGCCTCTGTGTTCCTCTTTCGCGTTCTCTCCGCCGGCGCCTCGATTCATCAACACAGCGAACCATTGTCCGCCACACATCGCTGCTTTCTTACCAGCCGGACCTGCCTCGCTCGCTCCTCCGTACATCAACGCGCTCAACACCGTGTGCACTCCCGCCTCTATCGCAGTACATATATGTCCATTAATACCTGCCGTTTTTGATTCCGATACTTTCTCAATACGCGTCACACTTTCTTCTACCTCAGAGGTCTGTTGCTAGTGACCACTTCTTACTGCTCTTGCTTCACCTTTGTTCGCTTCGATCTTGGAATTCATCCCTCCCGCTGGAGACGGTGTACGTAGCGCTTCCAGACCGATGGTGTACAGACGATTACTTCACGGAATGGCCCAAC
>m120107_231407_richard_c100267182550000001523003605171272_s1_p0/12360/37_1168
GCATCCCATCACTCAGCACCCCTTCGTTCCTTTTCCCACGTCTTGCTCATCCCCTTCAACGCGATGCGTCTGGTTTGTTTCCTCGCGTCTGTGTCCTCCTTCGCGGCTGGCGTCCTTGGCCGTCTCTCCAGATCAACACGGTCCGGCCAGCGCTGTTTGAGTTGCCAACCGACTCTCCTCTCCTGGAGCGGTGGAACCCCTCCCGTACTCTTGAGCGTCTCCCCGTACCGCCTTCGTCGCCGCCTCCAGTGACCTCGGCCTTCAGACCCGGCACCTCGTTCACGCTGGTCCACCAACCATCACCGCGATCACTTCTGTTGGCCTGCCCTCAAGGACAGCACTGGTGCCAATTGCCAGAGTCGGGCAGCATCCGATCCAGGCCGCTCTTGCTCCTGCTTGGTGGATCCAGTTCTCCACAGCCGGGGTTCGTGCAGGTTCGACGAGTGCCACGACGTCGGCAGGTACTACATCCTCTTCTTCTCTCCTGTCGGCCGCAACCACGTCATCTGCCCGAAAGCGTCTTCAGCGTCATGACCACTCTTCAGCTGCAGGATCGGGTAGCTCCTCTGCCTCTCAAGCTGGCTCCAGTACCTCGGCTGCGCCAGCTCCTCTGGCAGCCCTTCGTCGAGCGCCGGCGGCTCCACCAACGGCGTCAACTACGGTGTCGCGCCGTCGCCGCCGCCGTTTCGCCATGCTCGGATAAGCGGTTGCATGTTTTGAAAAGGTGGATGTTTCGTGGTTGCGTCACACCCTCCCATCCGCTCTTTGTTCCGTTTCTTTCTGCTCGCCCTCGAATAATCAAACGGCCATTTTTTCACACATGCGCTGTTTTACAGCCGCTTGCCTCGCTCGCTCCTCCGGTTACACTCAACCCCAACACGTAGTGTCCTCCGCTCCTCGCGTACATATATCCATTAATACTGGCCCGTTTTTGATTCCGTACTTTCTCATACGCAGTCCACTTTCCTCTACCTCGCGTCTGTTGCTAGTGGACTACTTCTTTATCTGCTCTTGCTTCACTTGTGCGCTTCGATCTGGATTCATCCCCTGCCGGAGACGTTGTATGTAGCTGCTTCGTGGGTGTACAGACGATTACTCCGATCCCACCCAACGACTCCGAGGTTCTTTTTC
>m120107_231407_richard_c100267182550000001523003605171272_s1_p0/80924/6855_8010
GCAGTCATCACCTCGAGCACCCACTTTCGTTTCCCTTTTTCCCACCGTCTGCTCATCCCTTCAACGACGATGAAGTCTGTGATTTGTTTCCCTCGCCGTCGTGTCCCTCTTCCGCGGCTGGCGTCCTGGCCAGGTCTCTCCGATCAACACGCCGCAGCGCTGTGAGTGCCAACCGACTCTCCTTCTCCCTGGAGCGGTGGAACCCCCCGTACTTCTTGAGCGTCGCTCCCCGGTACTCGCCTCGTCGCCCGCCCGCCAGGACCTCGGCACTCTGACCGGCACCTCGTCACCTTTTGTCCACCAACATCCACCGCCGAACCCTGTGGCCTGGACCCTCAAGGACAGCCACTGTGCCATTGCCAGAGCGCAGCATTCACGATCCAGGCCGGCCTTCCTCCTGCATTTGGTGGATCCAGTTCCTTTCCACCGCGCGGGTCGTCAGGGTTCGGACGAGGCCACGACGTCGGCAAGGTACTACACCTCTTCTTCGATCGTCTTGCGGCCGCAACCACGGCATCTGCCCTCGAAAGCGTCTCACGTCAGTGACCACTTCTTCAGCTGCAGGATCGGGTAGCTCCTCTGCCTCCAAACTGCCCAGACCCGGCTGCCGCCAGCTCCTCTGGCAGCCTCGTCGAGCAGCTCTGCCGGCTTCACCAACGGCGTCAAACTACGGTGTTCGCCGCCGCGCCGCCCCGTTTTTCGCCATGCCGGATACGCGGTTGCATGTGAAAGAGTGGGAGGTTCGGTGGTGCGCCACACCCTCCCCCATCCGCTCTTGTTCCGCTTTCTGCTCGCCCGCATAATCAAACGGACCATTTCTTCACCATCGCTTTTTACAGCCGCTGCCCTCGCGCTCCTCCGTTACACTCAACCTAACACGTAGTGTCTCGCTCTCCAGTACATGATACCATAAACCGCCGTTTGATCCTACTTTCTCAATACGCAAGACACACTTTCTTTCTACCTCCAGGGGTTCCCTTGGGGGTTTGGGGGCCCCCCTAAGGTGACAACTTCTTATCTGCTCTTGCTTCACCTTTGTTGGGCTTCGTTCTTGGGATTCATCCTCCGCCTGGAGGACTTGTATGTAGCGCTTCCACCGTGGTGTACAGACGATTACTCACGATCCCAACGACATCGAGGTTCTTTTTCTTTGGT
>m111101_082721_sidney_c100204702550000001519082301271284_s1_p0/9686/43_1253
GGCCAGTCTCACTCCCTAGACTTCGTTTCCCTTTCTCCGTCCTTGCTCATCCCCTTCCACGACGATGAACGTCTGCTGTTCTTTTCCCGCGTCACTCGCTGTATCTCTTCCGCGGCTGGCGTCCTTGCCAGCCTCTCGTCAGATCAACGCGCCCGCCAGCCCGTGTTGAGTGCAACCCAACTCCTCCTCCTCCTGGAAGCGTGGAACCCCCCCCTACTCTCTTGAGCGTCCTCCCGGTAACTCCGCCTTCGTCGCCGCTCCAGCCTCGCAACCAAGACCGGCACCCTCTTCCTGGGTCCACCACTCACCGCGACTCTGTTGCTGACCCTCGCCGCCTGCTCGCCATTCGCCCCGAGCCAGCCATCTCGATCAGGCCCGGCCTTCTTCCTCCTGCATTGGTGGATCCAGTTCCTCACGCCGCGGGTTCCGGTCAGGTTCGACGAGTGCCCACGAAACGTCGGCAGGTACACATCCTCTGTCTTCATCGTCTGCGGTCGCAACCCCGTCCCATCATGCCCCTCGAAAGCGTCTTCAGCCGATCAGTGACCAACTTCTTCCAGCTTGCAGGATCGGGGGTAGCTCCTCTGCCTCCAAGACTGGCTCCAAGTACCTCGGCCTGCGCCCAAGCTTCCTCTGGCACGCTCCGGTCGAGCAGCTTCTGGCCACTCGCCGGCTTTCACCAACGCGCCGTAACTACGGTGTGCCGCCGTCGCCCGCGCCCGTTTTCGCCATGCTCGGATTAAGCGGTTGCCATGTTTTGAAAAGGTGATGGTTTCGCGTTGGTTGCTCCACCACCTCCCATCCGCTCTTTGTTTCCGTTTCTTTCTGCTCGCCCTCGATAATCAAGACGGACCATTTTTTTTCCATCACGAAGTGCGCTTTTCACAGCCCTGCCCTCGCTCGCTCCTCCCGGGTTACCACTCAACCCTCAACACGTAGTGTCTCCGCTCTCGCAGACATATATCCATTACTACCTTGCCCGGTTTTGATTCCGTACTTTCTCAATCGGCAGTCACCACTTTCTTCTACCTCAGAGTCTGTTCCTAGTGACACTTCTTTAATCTGCTCGTTGCTTCACTTTGTTTGCGCTTTCGATCATTGGATTCATCCCTCCGAGCCTGGAGACGTTGTATGTATGGCGCTTCCCGTGGTGTACAGACGATTACTTCACGATCCCAACGACTATCGAGGTTTCTTTTTCTTTGGTTGC
>m111101_021445_sidney_c100204702550000001519082301271280_s1_p0/66923/1397_2588
CCAGGTCCCATCACTTCTAGCAACCCACTTGTTTCCTTTTCCCCACGTCTTGCTTCCCCTTCAACGGCGGACGATGAAGTCTTGTGTTTGTTTCCCCTCGCGTCTGTGTCCCTCTCGGCGGGCTGCGTCCTTGGCAGGTCTCTACAGATCACACGCCCGGGCCAGCCGCTGTTGAAGTGGCAACCGACTCTCTCTCCTGGAGAGCGGTGGAACCCCCCCGTTACTTCTTGAGCGTCCTCCCGGTAACTCGCCATTCGGTCGCCCGCCCCAGGACTCGGCACTCAGACCGGCAACCTCGTTTCACCTGGTCCACCCAACATCACCGCGATACCTCATGTTGGGCCTTGACCTCAAGGGGAACAGCACTGTGCCATTGCCAGAGCGCAGCATTCACGATCCAGGCGGCTCTTCCCTCCTGCATTGGTGGGAATCCAGTCCTCCACCGCGCGGGTTCGTCAGTTCGGACCGAGTCCACGGATCGTCGGCAAGTACTTACATCCTTCTTACTTCATCGTCTGCGGCCGGCAACCACGGTCATCTGCCTGAAAGGCGTCTTCAGCGGTTCAAGTGGAGCCTTCTTCAGCTGGCAGGATCGGTAGCTCCATGCCCTCCAAGACTGGCTCCCAGTACCTCGGCTGCCGCAGCTCCTCTGGCAGCGCTTCGTCGAGCGTCTGCCAGCTTCACCAAACGGCGTTTCACTACGGTGTCGCCGCCGTCGGCGCCGCCGTTTTTCGCCATGCTCGGATAAAGCGGTTGCATGTTTTGAAAAAGGTGGATGGTTCGTTGGTTGCGTCACCCCCTCCATCCGCTCTTTGTTCCGTTTTCTTTCTGCTCGCCCTCGAAATCAAACGGACCATTTTTTCACACATTGCTGCTTTTTACAGCCCCGCTGCCCCTCGCTCGGCTCTCGGTTACACTCAACCTTCAACACGTAGTGGTCTCCGCTCTCGCAGTACATATATCCATTAATACTTGCCGTTTTGATTTTCCGTTACTTTCTCATACGCAGTCACCACTTTCTTCTACTCAGAGGGTCTGTTGCCTAGTGACACCTTCTTTATTGCTCTTGCTTCACCTTGTTGCGCTTCGATCTTGGATCATCCCTCCCGCCCTGAGAGGACGTTGTATGTAGCGCTTCCACCGTGTGTACAGACGATTTACTGTCACGTCCCAACGGATTATCGAGGTTCT
>m111101_100030_sidney_c100204702550000001519082301271285_s1_p0/62689/2631_3807
GCAGTCTGATCCTCTACGCACCACCTTCGGTTTCCATTTTCCCACGTCTTGCTCATCCCGTTTCAACGAACGATGAGTCTGTGTTTGTTTCCGTTCGCGTCTGTGCTCCTCTTCGCCGGCTGGGTCCTTGGCCGTCTCTCACTCAACACGCCGGCCCGCGCTGTTTGAAGTGCCAAACCGATCTCCTCTCCTGGAGCGGTTGGACCCCCGTATCTCTTGAGCGTCCTCCCGGTAACGTCGCCTTCCGTCCGCACCGCCTCCCAGGACCTCGCACTCGCAGACCGCACGTCGTTTCCACCTGGTCCACTCCCGCCGCGATACCTCTGTTGGCTGACCTCAAAGGACAGCACTGGTGCATTGCCCAGAGCGAGCATTACACGATCCAGGCGGCTCTTCCTCCCTGCATTGGCGGGAAATCCAGTTTCCCTCACCGCCGCGGGTTCGTGCAGGTTTCGACGAGTGGCCACGACGTCGGCAGGGTTACCTCCTCTTCTTCCCTCGTTGGGCCGCAACCGACGGTCCTCTGCTCGAAGCGTCTTAGCGTCCAGTGCCACTTCTTCAGCTGCAGGATCGGGTAGCTTCCTCTGCTCCAAGAACTGGACCTCCCGGTACCTCGGCCTGCCGCAGCTCTCTGGCCGCGCCTTTCGTCGAGCGCTCTGCGGCTTTCACCACACGCGGTCAACTACGGGGGTGGTCGCCGCGTCGCCGCGCGTTTTGCCATGCTCGGATACGCGGTTTCGCCATTGTTGAAAAGGGTTGGCTGGTTTCCCGTTATGGTTGCGTCCACCCCTCCCCATCGTCTTTGTTCCGTTTGCTTTCTGGCTCGCCTCGACTCATCCAAACGGCATTTTTTCCACATCATGCGCTTTTTTTAACAGCCGCCTGCCCCTCCGTGCTCCTCCGGTTACTCCAACCTCACACGTAGTGGTCTCCGTCTCGTCAGTAACATACTATCCCAGTTTAATACTGCCGTTTTGATTCGTATTTCTCAATCGCAGTCCACACTTTCCTTCCTACCTCAGGAGTCCTGGTTTGCTAGTGGATCACTTCTTTATCTGCCTTGCTTACTTGTTGCGCTTCGTCTTGGATTCATCCCCGCCTGGAGACGTTGCATGTGCGCTTCACGTGGGTGTCAGACGATTACTTCCGATCCCAAGACTATCGAGGTTCTTTTTT
>m111101_082721_sidney_c100204702550000001519082301271284_s1_p0/55643/1401_2638
CAGTTCCCATCACTCTTAGCACCCACTTTCGTTTCCCTTTTCCCCACGGTCTTGCTCATCCCCTTTCAAGCGACGATGAAGTCTGTTGTTTGTTTCCCTTCGCGGTCTGTGGTCCCTCTTCGCGGCTGGCGTTCTTGCCAGTCGTCTCAGTTCCAACACGCCGCCAGCGCTGTTGAGTTGCCAACGACTCTCCTCTCCTGGAGTGGAAACCCCCCGTATTCTTGGAGCGTCTCCCCGGTAACTCGCCTTCGTCGCCGCCCTCCCAGGACCTCGGCAACTCGACGCGGCAACCTCGTTCACCTGTTCCACCAAACATCACCCGCCGATAACTCTGTTTGGCCTGACCCCTCAATGACAGCACTGGGTGGCCATGCCCAGGAGCGCAGCTTCACGATCCAGCCGGCTCTTCTTCCTGGCATTGGTGGATCCCAGTTCCTCCGACCGCCGCTGGGTTCGGTCAGGTTTGTTCGGGAACGAGTTGCCACGACAGTCGCAGGGTACTACTCCTTCTTCTTCATTCGTCTGCGGCCGCAAAATCCACGTATCATCTGCTCGAAAGTGCGTCTTCAGCCGTTCAGTGACCACTTCTTCAGCTGCCAGGAATCGGGCTCGCTCCCTCGCCTCCAAGGACTGGCTGCAGTACCTTCGGCTGCCGGGCCAGGCTCCGTCTGAGCAAGCGCTTCGGCGAGCTCAGCTCTGCCGGCTTCACCAACGGGCGTCAACTTACAGGTGTCCGCCGCCGTCCGGGCGCGCGCCGTTTTCGCGATTGCTCGATAAAAGCGTTGCATGTTTTGAAAAGGTGGAGGGTTTTCGTTGGTTGCGGTCACCACCTCCCATCCGCTCTTTGTTCCGTTTCTTTCTGCTCGGCCCTCGATAATCAAAAACGGGACCATTTTTATCACACATGCGCTTTTTTACAGCCGCTGGCCCTCGGGCTCGCTCCTCCGGTTACACTCAACCCTCAACACGTAGTGTCTCCGCTCTCGCAGTACCAATCCATTAATACCCTTTTGCCCGTTTTGATTCCGTACTTTCCTTCAATACGCAGCACACTTTCTTTACCTCAGAGTCTGTTCCTAGTGGACACTTTTATTCTGCTTTGCTTCACCTTTGTGTGCGCTTCGATTCTTGATCATCCCTTCCCGCCTGGAGACGTTGTAATGTAGCGCCTTCCACCCGTGGGTGTACGACGATTACTTCACATTCCCAGACGACTTATCGAGGTTTCTTTTTTTCT
>m120107_231407_richard_c100267182550000001523003605171272_s1_p0/80924/5600_6749
GCAGTCATCACTCAGCACCACTTCGGTTTCCTTTCCCCACGTTTGCTCATCCCCTTTCAACGACGTGAAGTCTGTGTTTGGTTCCCATCGCGTCTGTGTCCTCTTCGCGGCTGGCGTCCTTGGCCAGTCTCTCCAGTCAACACGCCGGCCAGGCTGTTGGTGCCAACCGACTCTCCTCTCCTGGAGCGGTGGACCCCCGTACTTCTTGAGCGTCCTCCCGGTAACTCCGCCTTCGTCCGCCCGCCCTCTCAGGACTCGGACTCAGACCGGCACCTCGTACCTGGTCACCAAACATCACCGTCCGATACCTCATGTTGGCCTGACCCTCACGGGACAGCACCTGTGCCATTGCGCCAGAGCGCAGCAATTCACGATCCAGGCGCGCTCTTCCTCCTGCATTAGGCGGGTGGATCCAGTTGCCTCCACCGCCCGCGGGTTCGTCCAGGTCGACGAGTGCCACGACGTCGGCAGGTACTACATCCTTTCTTCATCCGTCTGCGGCCCGCAACCACGTCATCTGCCTCGAAAGCGTCTTCAGCGTCAGTGACCACTTCTTCAGGCTGGCAGGAGCGGGTAGCTCTCGCCCTCCAAGACTGGCTCCAGTACCTCGGCTGCCGCAGCGTCCTCTGGCAGCGCTTCGTCGAGAGCTCTGCCGTTCACCCAACGGCGTCACTACGGTGTCGCCGCCGTCGCCGCCGCCGTTTCGCCTGCTCGGATAACGGTTGCATGTTTGAAAAGGTGGATGTTTTCGTTGGTGCGTCCACACCCTCCCCATCGCTCTTGTCGTTTCTTTCTGTCGCCCTCGATAATCAAACACGGGGAACCCCCCCATTTTTTCAACACATGCGCTTTTACAGCCGCTGCCTCGCTCGCTCCTCGGTTACACCACCCTCAACACACGTAGTGTCTCGCTCCGCAGTACATATATCCATTATACTGCGTTTTGATTCCGTACTTTCTCATCGCAGTCACACTTCTTCTACCTCAGAGTCTGTTGCCTAGTGACCCTTCTTTAATCTGCCTCTTGCTTCACCGTTGTGCGCTTCGATCTTGGATTCATCCTCCCGCTGGAGAACGTTGTATGTAGCGCTTCGCACCGTGGTGTACGAAGTGACTCTCACGGATCCCACGAACTATCGAGGTTCTTTT
>m111101_065412_sidney_c100204702550000001519082301271283_s1_p0/16311/1319_2535
GGCCATCCATCACTTCTAGCACCAACTTCGTTTTCCCTTTCCCCCACGTCTTGCTCATCCCTCAACGACGATGGAAGTCTGTGGTTTGTTTCCTCGCGTCTGGTGTCCCTCTTCGCGGCTGGCGGGTCACTTGGCCAGTCTCCTCAGATCAAACACCGCCGGCCAGCGCTTGTGGAGGTGCCAACCGATCTCCTCTCCTGGAGCGGTGGAACCCCCCCCGTAAACTCCTTGAAAAGCGTCTCCCGTAACTCGCCTTCGTCGCCCGCCCTCCAGTGACCTCGGCACTCAGAAACCGGCCACCCTCGTTCACCTGGTCCCACTCCAACATCCCCGCGATACTCTGTTGGCCTCACCTCAATGGACAGCACTGGTGCCCCATTGCCAGAGCGCAGCATTCACGAATTCAAGGCGGCCTTCTCCTGCCCCATTGGGTGGATCCATTCCTCCAACCGCCCGGGGTTCGGTCAGGGTTCCGACGAGTGCACACGTCGCAGGTTACCTACATCCTCCTCTTCAATCGGTCCCTGGGGCGCAACCACCGTCCATCTGCCCCTCGAAGCGTCTTCAGCCGTCAGTGACCACTTCTTCAGCTGCCAGGATCGGTAGCTCCTCCTGCCCAAGACTGGCTCCAGTCCTCCGGCTGCCGCCAGCCTCCCTCTGCAGCGCTTCGTCCGAGCCAGCTTTCTGCCCCGCTTCCACGGCGTCAACTACGGGTGTTCGCCCGCCCGTCGCCGCCCGCGTTTTCGCCCATGCTCAGATTAAGCCGGTTGCATGTTTGAAAAGGTGGAATGGGTTTCGTTGGTTGCGTCCACACCCTCCCATCCGCTCTTTGTTCCGTTCTTCTGCCTCAGCCTCGAAATCAACGACCATTTTTTTCACAATGCGCTTTTTACAGCCGCTTTGCCCTCGCTCGCTCCTCCCGTTACCACTCAACCCTCCAACACGTAGTGGTCCCGCTCTCGCAGTACATATATCGCATTAATATCCTGCCGTTTGATTCCTACTTTCTCATACGCAGTCACACTTTCTTCCTTACCCTCCAGAAGGTCCTGTTGCCTAGTGAACAACTTCTTTTATTTGCTCTTGCTTTCACCTTGTTGCGGCTTCGGATCTTGGGATTCATCCCTCCCGCCTGGAGACGTTGTATGTGCGCCTTCCACCGTGGGTGTACAGACCGATACTTCACAGGATCCCAAGACCTATCGAGGTTCTTTTT
>m111101_100030_sidney_c100204702550000001519082301271285_s1_p0/3882/38_1254
GCAGTCCATCAAATCTAGCATACCCACTTCGGTTTCCGGTTTTCCCCACGTCTTGCTCATCCCCTTCAACGACGATGAAGTCCCTGTGGTTTGTTTCCCTCCGCGTCTTGGTCCTCTTCCGCGCTGGCGTCCTTTGCCAGTCCCATCTTCCGATTCAACACGCTGGCCAGCGCTGTTGAAGTGGCCAACCGACTCTCCTCTCCTGGGAGCCGGTGGAACCCCCCGTACTTCTTGAGCGCCGTCCTCCCGGTAACTCGCCTTTCGTCCGCCCGCCCTCCCAGGACCTCGGCATCAGACCGGCACCTCGTTCCACTGGTCCAACCAACATACCGCGGATAGGCCTCTGGTTGGCCTACCCTCCAGGACAGCTACTGGTGCCATTGCCAGAGCGCAAGCATATCACGATCCAGGGCCTGGGCTCTTTCTCCTGCATTGTGGGATCCAGTTCCTCCACCGCCGCGGGTTCGTCCAGGTTCGACGAGTAGCCAACGACGTCGCCAGTACTACATCCTTCTTCTTCATCGTCTGCCGCAGCCCACCAACGTCATTCTGCCTCGAAGCGTCTTTTCAGCGTCAGTAACCACTTCGTTCAGCTGCAGGATCGGGTAGCCTCCTCTGCCTCCAAGACTGGCTCCAGTTACCTTCCGGCCCTGCCCGCCAGCCTCCTCTGGCAGCGCTTCGTCCGAAGCAGCTCTGCCGGCTTCACCAACGGCCGTCCAAACTACGGGTTCGCCGCCCGTCGCCCGCCGCGTTTTCGCCCATACTGGATAAGCCGGTTGCATGTTTTGAAAAGGTGGTGGTTTCGTTGGTTCGTCCACACCTCCCCATCCGCTCCTTTGGTTCCCGTTTCTTCTGCTCGCCTCGATAATCAAACGGACCATTTTTTCACACATGCGGCTTTTTAACAGCCGCTGCCCTCGCATCGCTCCTCCGGTTACACTCACCCTCAACACGTAGTTCCTCCGCTCTCGGCAGTACTATATCATTAATACCTGCCGTTTGTTCCTGTACTTTCTCATAGCAGTTCACACTTTTTCTTCTACCATCAGGAGGTCTGTTTGCCTAGTGACACTTCTTTTATCTGCTCTTGCTCACCTTGTTCGCTTCGATTCTTGGATTCATCCCTCCCGCCCTGGAAGACGTTTGTATGTAGTGCTTCACCGTGTGGTACAGAACCGATTTACTTCGATCCAACGACTAATCGAGGTTCTTTTTT
>m120107_231407_richard_c100267182550000001523003605171272_s1_p0/66741/23_1247
AAGCAGTCCATCACTCTAGCACCCACTTCGTTTCCCTTTTCCCCACGTCTTGCTCATCCCCTTCAACGACGATGAAGTCTGTGTTTGTTTCCCTCGCGTCTGATGTCCCTCTTCGCGCTGGCGTCCTTGGCCAGTCTCTCCAGACTCAACACGCCGCCAGCGCGTTGAGTTGCCAACCGACTTCTCCTCTCCTGAGCGGTGAACCCCCCGCTACTTCTTGAGCGATCCTCCCCGGTAACTCGCCTTGCGTCGCCCGCCTCCCAGGACCTCGCACTCAGACCGCACCTCGTTCACCTGGTCCACCAACATCACCGCCTGAGTACCTCTGTTGCCTGACCCTCAAGGACCAGCACTGTGCCCATTGCCCCAGAGCGCAGCATTCACGGATCCAGCCGGCTTCGTCCTCCTGGCATTGGTGGAGGTGCGCAGTTGCCTGTGCGAGCGGCGCCGCGGTTCGTCCACGGTTCGACGAGGCCACGACGTCGGCGAGGGGTACTACATCCTGCTTCGTGCGCGAGTCGGTCTGCGCCGCAACGCAGCGGTCATGCTGCCGTCGAGAAGCGTCTTCGAGCGTCAGGTGACCACTTCTTCAGCTGCGAGGATGCGGTAGCTCCTCTGGCGCTCCAAAGACTGGCTCCAGGTACCTCGGCTGGCGCCAGCTCCTCTGGCCAGCGCTCGTCGAGGCAGCTCGCCGGGCTTCACCAACGGCGTCACTACGGGTCGCCGCGCGTCGCCGCCGGCCGTTTTCGGCCGATGCTCGGAAAGCGTTGCGATGTTTTGAAAAGGGTGGTGGTTTCGTTGTGGCGTCCACCCCTCCCCAGCCGCTCTTTGTTCCGTTTCGTTTCTGCTCGCCCTCGATTAATCAAACGACCATTTTTTCACACATAGACGCTTCTTTACAAGCCGCCTGCGCCTCGCTCGCTCCTCCGGTTACACTCAACCCTCACACACGTAGTGTCTCCGCTCTCGCAGTGAGAGTGAGTATCATTCATACCTGCCGTTTTGAAGGTTCCGTACGTTTCTCAATACCGCAGTCACACTTTCTTCTACCTCAGATGTCGTGTGCCTGGACACTCTGATATCTGCTCTTGCTTCAGCCTTGTTGCGCTTCGGATCTTGGATTCATCCCCCGCCGTGGAGGACGTGATGTATGTAGCGCTTCCAGCCGTGGTGCTACAGACGGATTACGTCACGATGCCCCAACGACTATCGAGGTTCTTTTTC
>m120107_231407_richard_c100267182550000001523003605171272_s1_p0/36695/3363_4630
GGCCAGTGTCCATCCACCGTCTAGCACCCACTTCGTTTCCCTTTTCCCACGTCTTGGCTCATCCGCCGTTCAACGACGATGAAACGGTCTGTGTTTGTTCGCCTTCGCGTCTGTGTCCTCCTTCTCGGCGGTCTGGCGTCCTTGGCCAGTCTCTCCAGATCAACACGCCGGCCAGCGCTGTTCGAGTGCCAACCCGACTCTCTCCCTGGAGGCGCGTGACCGCCCCCGTACTTCCTTCGAGCCGTCCTCCCGTAACGTCGCCTTCCGTGACCAGGCCCGCCGCCTCCAGGACTCGCACCTCAGACCCGGCACCTGCGTTCAGCCTGGTCCACGCAACATCACCACCCGCTACCTGCTGTTGCCTGACCTCCGCTCAAGGACAGGCACTGTGCGCATTGGCCAGAGCGCAGCATCAGCGATCCAGGCGGCTCTTCGTCCTTCATTTGGTGGATGCCAGTTCCTCCACGCCTGCCCGGCGGGTTCGTCAGGTTCGACCGAGGTGCCACGACGTCGGCAGGTACTACATCCTCTTCTTCCATCGTCTGGCGGCCGCACCACGTCATCTGCCTCGAAAGCGTCTTCAGCGTCATGACCACTTCTTCAGGCGCTGCAGGATGCGGGTTAGCTCCTCTGGCCTCCAAGCTGGCTCGCAGTACCCTCGGCTGCCGGCAGCTCCTCTGGCAGCGCTTCGTCGAGCAGGCTCCCTGGCCCCGGCTTCACCAACCCGGGCGTCAACTACGGTGTCGCCGCGTCGCCGCCGCGTTTTCGGGCCATGCTCGGATCCCCCGCGCTTGGCATGTTTATGAAAAGGTGATGGTTTCGTGGTTGGCGTCGGCACACGCCTCCCATCCGCTCTTTGTCCGCGTTTCTTTCTGGCTCGCCCTTCGATACTCAAACGGAACCTTTTTTCACACATGCGCTTTTTACAGCCGCTGCCTCCGCTCGCATTCGGCCTCCGGGTATACACTAACCCTCAACACGTAGTGTCTCCGCTCTCGCAGTACATATATCTCATTATACCCTGGGGCCGTTTTGATTCCGTACTTTCTCAATAGCGGCAGTCACACTTTCTTCTACCTCAGAGTCTGTGCCTAGTGACACTTTCTCTCTTATCTGGCTGCTTGCTTCACCTTGCGTTGGCGCTTCGATCTTGGATTCATTCCTCCCGCCTGGAGACGTTGTATGTAGCGCTTCGCAGCCGTGTGTACAGACGATTAGGCTTCACGATCCCAACGACTATCGAGGTTCTTTTTCTTTGTTGCTAGAT
>m111101_021445_sidney_c100204702550000001519082301271280_s1_p0/26435/39_1260
GGCCAGTCCATCACTCTAGCCCACTTCGTTTCCTTTCCCACGTCTTGCTCAATCCCTTCCCACGACGATGAGTTCTTGTGGTTTGTTATCCACAACAACAAAACTCGCGTCCTGTGTCCTCCTTTCCGCGGCTGGCGGTCCTTGGGCAGTCCTCTCCAATCACACGCCGGCCAGCGCTGTTGAGGCAACCGACTTCTCTCCTCTCCTGAGGCGGTTGGAAACCCCCCGTACTTCTTGAGCGTCCTCCCGGTAACTTCGCCTTCGTCCGCCCGCCCTCCAGGACTCGGCACTCAGACCGGCACCTCGTTCCACCTCTTGTCCACCACATCACCGCGTGCCGATACCGTCCGTGTTGGCCTGACCTCAGGACAGCACTGGTGCCATTGCCCAGAAGCGGACAGCAGTCACGGAACAGATCCAGGGCCGGCTTTCTTCCTCCTGCATGGTGGATCCCAGTGTCCTCCAACCGCCGGCGGGTTGTCAGGTTCGAGGAGTGCCACGACGTCGGCAAGGTACTACATCCTCATCCTCCATCGTCTGCGGCCGCAACCACGTCAATCTGCCTCGAAAGCGTCTTCAGCGTCAGTGACCCCACTTCTTCAGCTGCAGGATCCGGGTAGGCTCCTCTGCCTTCCAAGACCTGGCTCCAGTACCGTCGCTGCCGCCGAGCTCTTCTGGCAGCGCTCGTCGAGCGGCTCTGCCGGCTTTCACCACGGCGTCAACTACGGTGTCGGCCGCCGTCGCCGCCGCGATTTTCGCCATGCTCGGATAAGCGGTTGCATGTTTTGAAAAGGTGGATGGTTTCGCTTGGTTGCGTCACACCTCCCCATGCCGCTCTTTGTTCCGTTCTTCTGCTCGCCCTCGATAATCAAACCGGACCATTTTTTCACCACTGCGCTTTTTAAGCCGCTGGCCTCGCTCGCGTCCTTCCGTTAACACCTCAAACCTCACGACGTAGTGTCTCGCGCTCTCGCAGTACCATAATCCATTAATACCTGGCCGTTTTGATCCGTACTTTCTCCAATACGCAGTTCACGACTTTTCTTTCTACCTCAGAGTCTGTTGGCCTAGGACACTTCTTTTATCTGGCTCTTTGCTTCACTTGTTGCGCTTCGATCTTGATTCATGGCCTCCCCGCCTGGAGACGTTGTATGTAGCGCTTCCACCGTGGTGTACAGACGATTACTTCAACGATCGCCAACGACTAATCGAGGTTCTTTT
>m120107_231407_richard_c100267182550000001523003605171272_s1_p0/80924/1682_2867
CAGTTCCATCGACTCGAGCACCGCACTTGCGTTTCCCGTTCCCCACGTCTTGTCATCCCCTCACAACGACGATGAAGGTCTGTGTGTGGCTTTCCCCTCGCGTCGTGTCCCGTCTTGCTGGCTGGCGTCCCGTGGCCGCAGTCTCTCCAGATCAAACACGCCGGCCAGCGCTTGAGGTGCCAACCGACTTCTCCCTCTCCTGGAAGCGGTGGAACCCCCCGTAGGCTTCTTTGAGCGTCCCGTCCGCCGGGTAACGTCGCCTTGCGTCGCCCGGCCCCTCGCAGGACGCTCGGCAGCGTCTGCCGGCACTGCGTCACCTGTGCCACCAACATCCACCGCCGAGTACCGTCTGTTGGCCTGGAGCCCTCAAGGACAGCCCACTGGGTGGCCATGCCAGAGGCGCAGCATTCCACCATCCAGGCGGGGCTCTTCCTCCTGCATTGGTGGATCCAGTTCCTCACCGCCGCGGTCGTCGGTTCGGAACGAGTTCCACGACGTCGGCAGGTACTACCTCCTCTTCTTCATCCTTCTGCGGCCGCAACCCACGTCATCGCCTCGAAAAGCGTCTTCAGCGTCAGACCACTCTTTCAGCTGCAGGACGGTAGCTCCCTCTCGCCGCCAAGACTGGCTCCAGTACCTCGGCTGCCCGCCGCTCCTCTGGCACGCTTCGTCGAAAGCAGCTTCTTGGCGGTTCACCAACGCGCAACTACGGTGTCCGCCGCCGTCGCCGCCGCGTTTCGCCATGCGCGGTAAGCGTGGCGATGTTTTGAAAAAGGTGGAGGGATTCGTGGTTGCGTCCACACCCTCCATCCGCTCTTTGTCCGTTTGCTTTCTGCTCTCCCTCGATAATCAAACGGACCATTTTCACACAGCGCTTTTTACAGCCGCTGCCCCGCTCGCTCCTCCGGTTACACTCAACCCCAACACGTAGGTGTCTCCGCTCCGCAGTAATATTCCATTAATACCCGGCCGTTTTGATCCTTACTTTCTCAATGACGCAGTCACACTTTCTCCTACTCCAGAGTCTTTGCCTAGTGACACTTCTTTATTGTCTCTGCGGTGGCGACCTTGTTGCGCCTTCGATCTGGATTCAAAATCCCCTCCGCCTGGAGACGTTGTATTAGCGCTCCCCGTGGGTGTACAACGATTACTTCACGATCCCACCGACTACGAGGTTTTTTTTTG
>m120108_004716_richard_c100267182550000001523003605171273_s1_p0/13051/5260_6591
GGGCAGTCATCACTACTAGCAGCGCGCAGGCTTCGTTTCCTTTGTCCGACGACAGACTTGGCTCATCCCTCTGTGTCCAACGAGGCGATGAAGTCTGCGTTTGTTCCGGCTCCAGTCTGTGGTCGCCCTTCGCGGCTGTGCGTCCTTGGCCAGTCTTACAGATCAACAGCGCCGGCCAGGCCGCTGTTTGACGTGGCCAACCGACTCTGCCTCTCCTGGGCGTGAACCCCGCGTACTTCTTGAGGCGTCCTCGCCGGCTAACTCGCGCCTTCGTCGCCCGGCCCTCCAGGAGACCATCGGCACTCAGACGCGCGACAGCCTGCGTGTCCCTGGTCCACAACATCACCCGCCGATACCCTCTTTGGTCCTCGTAAACGGTGGAAAATAAATCCCTGACGCCTTCAAGGACACAGGCTGGTGCCATTGCCTCAGAGCGCAAGGGCATGTGCAGCAGATCCAGAGGCCGGCTCTCTCCTGGGCATTGGTGATCCAGTTCCTCCGCACCGCGCGGATTCGTCCAGGTTCGACGAGTGGCCCACGACAGTCCGGCAGGTACTACATCCCTCATCTTCATCGTCTGGGGGCGCGCGCAACCAACGTCATCTGCCTCCGAAAGCGTCTTCAGCGTCAGTGACCACTTCTTCAGCTGCAGGATCGGGTAGGCTCCTCTGCCTCCAAAGACTGGCTCCAGTACCTCGGCTGGCCGCCAGCCCTCTGGGGCAGCGGCTTCGTCGAGGGCAGCTCTGCCGGCTTCACCAACGGCAGTCAACTAGCGGTGTCGCCGCCGTCAGGCCGGCCGCCGTTTTCGCCATGCCGATAAGGCGGTTGCATTTTGAAAAGGTGGATGGTTTCGTTGGTTGCGCCCAGCCTCCGCTCATCCGCTCTTTGTTCCGTTCTTTCTGCTCGCCTCCGATAATCAAACGGAACGGCATTTTTCACACATGCCTTTTTAGCAGCCGCTGGCCCCGCTCGGCTCCTCCGGTTAGCACTCCAAAACCTCAACAGCGTAGGTCTCCACCATATATCGCAGTACATATATCCATTATAGCCCTGGCGTTTTGATTCGCGTACTTTCTCAATACGGCAGTCAGGACTTCTTCCTAACCTGCAGAGTCTGTTGCCTAGTGACACTTAATTTATCCTGGCTCCTTGCTCCACCTGTTGCGCTGCGATCTTTGGATTCATCCCTCCGCCTGGAGACGTTGTATGTAGCGGCTCCACCCGTGGTGTACAGACGATTACTCACGATCCGCAACGACTACACATCGACGGTTCTTTTTCTTTTGGTTGCTAGATGATGGATTCACAGATCATTAGCTCTGTGAAAAAAG
>m120107_231407_richard_c100267182550000001523003605171272_s1_p0/7571/36_1234
GGGCAGTCATCACTCAGCACCTCACTCGTTTCCCTTTTCCCACGTCTTGCTCATCCCCTTCAACGACGAGAAGTCTGTGTTTGTTTCCCTCGCGTCTGTGTCCCTCTTTCGCGGCTGGCGTCCTTGGCCAGTCCTCGTCCAGAGATCAACACGCCCGGCCGCGCTGTTGAGTGCCAACCGACTCTCCTCTCCTGGAGCGGTGGACCCCCCGTACCTCTTAGCGTCCTCCCACGGTTAACTCGTCTCTTCGTTCGCCCGCCCTCCAGACTCGGCACTCAGACCGGCACCTCGTCACGCTGGTCCACCAACATCACCCGGCCGATACCCTCTGTTGGCCTGACCCTCACAGGACAGCACTGTGCCATTGCCAGAGCGCAGCATTCACGATCCAGGCGGTGCTCTTCTCCTGCATTTGGTGGATCCACTTCCCTCCACCACCGGCCGCGGGTTCGTCAGGTTCGACGCGAGTGCCACAGACGTCGGCAGGTACACATCCCTCTCTTCCATCGTCTGCGGCCGCAACCAACGTCATCTGCCTCCGAAAGCGTCTTCGCGTCAGTGACACTTCTTCAGCTTGCAGATCGGGTAGCTCCTTCTGCTCCAAGACTGGCTCCATACCTCGGCTGCCGCCAGCTCCTCTGGCAGCCGCTTCGGTCGAGCAGCTCTGACTGCCCGGCTTCACCACGGCGTCAACTACGGTGTCCGCCGCCGTCGTCCCGCGCCGTTTTCGCCCTGCGTCCGATAAGCGGTGCATGTTTGAAAAGGTTGGGGGGGGGGGGGGGGGGATGGTTTCGTTGGTGCTCCACACCCTTCCCCATCCGCTCTTTGTTCCGTTTCTTTCTTGCTCGGCCCTCGATAATCAAACGGACCATTTTTTCACACATGCGCTTTTTACAGCCGCTTGCCTCGCTCGCTCTCGGTTTACCACTCAACCCTCCAACACGTAGTGTCCTCCGCTCTCGCAGTACATATAATCCATTAATACCTGGCCGTTTTGATTCCGTTACTTTCTCAATACGCAGTCACACTTTCTTCTACTCAGAGTCTGTTTTGCCTAGTGACACTTCTTTATCTGCTCTTGCTTCACCTTGTTGCGCCTTCGATCTTGGATTAATGCCCCCGCCTGGAGACGTTTATGTAAGCCGCTTTCACCGTGGGTACAGACGATTACTTCACGATCCACGACTATCGGGAGGTC
>m120108_004716_richard_c100267182550000001523003605171273_s1_p0/581/41_1271
GGCCAGTCATCCTCTTCTAGCACCCACTTCGTTTCCTTTTCCACCAGTTTGCTCATCCCCTTCAACGACCGATGAAGTCTGGTGTTTGTTTCCCCCGGCTCGCGTCTGGGTGTCCTCTGCGCGGCTGGCGTCCCTTGGCCGTCTCTCCAGATAACACGCCCGGCCGCGCTTGTTGAGTGCCAACGGACCTCCCCCTTTGTTCGCTCGTCCTGGGAGCGGGTGGCTACCCGGCCGGTCTTCGTTGAGGCGGTCCCCTCTCCGGGTATCTCGCTTCGTCGCCAGCCTCCCGGCTCTGGCACTCAGACCGGCACCCGTCGTTCAGCCCTGGGTCCACAACCATCACCCGCCGGACGTGCCGCCTCGGAGGTGTTGCCGTACGCCTCAAGCGGACAGCACTCGGTGCCATCTGCCCCGAGCGCAGCTTTCCACGATCCAGGCCCGGCTCTTCCTCCTGCATTGGTGGATCCAGTTCCTCCAGCTCGGCCGCGGGTTTCGTCAGGTTCGACGAGTGCCACGCACGTCGGCGGTACCTACATGCCTCGTTCTTCCTCCGTTCTGCGGCCGCAAACCCGTCAGTCTGCCCTCGAAAAGCGTCTTCAGCGGTCAGTGACCACTTCTTCAGCTGCAGGATCGGGTAGCGCCCTCTGCCTCCAGACTGGTCCAGTACCTCGGCCTGCGCCAGCTCCTCTGGCACGCTCGTCGAGGCAGCTCTGCGGCTTCACCAACGGCGTCAACTACGGTGTCGCCGCCTCGCCCGCGCCGCCGTTTTCGCCATGCTCGGATAAGCGGTTGCATGTTTTGAAAAGGTGGATGTTTGTTGTTGCGTCACACCCTCCCTGTCCGCTCTTTGTTTCCGTTTCTTTCTGCTCGCCCTCGATAACCAACCGGACCATTTTTTCACCAGCGTAGCCCTTTTACAGCCGGCTGCTCCTCGCTCGCTCCTCCGGTTACACTCAACCCTGCAACACGTAGTGCTCCGCTCATCGCAGTACATGATATCCATTAATACTGCCGTTTTGATTCCCGTACTGTTCTCAATACTGCAGTCACTTTCTTCATACCTTCAGAGGTCTGTTGCCTAGTGACACTTCCTTTATCTGCTCTGCTTCTACTTGTTGGCTTCGATCTTGGATTCATCCCTCCCGCGCTGGAGACGTTGTATGAGCGCGTTCCACCGTGGTGTAGCAGACGATTACTTCACGATCCCCACGACTATCGAGGTTCTTTTTC
>m111101_082721_sidney_c100204702550000001519082301271284_s1_p0/72853/30_1270
CCAGTCCCATCACTCTAGCACCCACTTCGTTTCCCTTTTCCCCACGTCTTGGCTCATCCCCCCTCAACGACGATGAAGTCTGTGTTTGTTTCCCTCGCGTCTGTGCCCTCTCGGCGGCTGGCGTCTCTTGGCCAGTCTCTCCAGATCAACCAACGCGGCCAGGCTGTTGAGTGCCAAGCCCGACTTCTCCTCTCCTGGGAGCGTGGGAACCCCCCCCGTACCTTCTTGAAGCGATCCTCCCCGGTAACTCGGCCCTTCGTCCGCCGCCCCTCCAGGAACCTCGGCACTCAGACGGGCACTCGTCACCTGTCCACCAACATCACCGCCGAACCTCCTGTTGGCCTGGACCCTCAAGACGAGCAACTGGTGGCCAATTGCCCAGAGCGCAGCATTTCACGATCCAGGCCGGGCTTCTCCTTCCTGCATTTGGTGGATTTTCCAGTTCCTCCACCGGGCCGCCGGTTCGTCAGGTTCGACGAGTGCCACGACCGTCGGGCAGTTACATACATCCTCTTCTTCATCGTTTCTGCGCCGCAACCCACGGTCATCTGCCCTCGAAAGCGTCTTCAGGCGTCAGTGGACCACTTCTTTCACTGCAAGGATCGGGTAGCTCCTCTGGGCCTCCAAGACTGGGCCCCCAGTTACCTCGGCTGCCGCCAGCTTCCTCTTGGCAGCGCCTTCCGGTCGGAGCAGCTTCTGCCGGGGCTTCACCAACGGGGCGTCAACTACGGTTGTCGCCGCCCGATCGCCGCGCGCGTTTTGCCCCATGGGCCTCGGATAAAGGGCTGCATGTTTTGAAAAGGGTGGATGGTTTCGTGGTTGCGGATCCAACACCCTCCCCTCCGCTCTTTTTCCGTTTCTTTTCTGCCTCGCCTCGATAATCAAACGGGACCATTTTTTTCAAACCATGCGGCTTTTTAACAGGCGCTGCCCTCGCTCGGCTCCCTCCGGTTACCACTTCAACCCTCAACACGTAGTGTCTCCGCTTCGCATACATATATCCATTAAACCTGCCGTTTGATTTCCGTACTTTCTCAATACGCAGCACACCTTCTTTACCTCAGGAGTCTGTTGCCTACGTGAGCACTTTCTTTATTCTGCTCTTGCTTCACCTCTTTTGCGCTTGCGATCTTTGGATTCATCCCTTCCGCCTGGAGACGTTGTAGTAGCGCTTCCACCGGTGGTGTACAGGACGGATTACTTCACGATTCCCAACGGACTACGAGTTCTTTTCTTTGGT
>m111101_021445_sidney_c100204702550000001519082301271280_s1_p0/29407/38_1271
GCCCGCAGGTCATCCACTCTAGCACCCACTTCGTTTCCTTTTCCACGCTTGCTCATCCCCCTTCTAATACACGAATGGAATCTGTGTTGTTCCCTCAGCGGTCTGTGTCCTCTTCGCGGCTGGCGTCCTTGGCCAGTCGTCTCCAGATCCAACACGCGTCCGCCCCCGGCCAGCGGCTGTTGAGTGCCAACCGACCTCCTCTCCTGGAGCGGTGGAACCCCCCCGTACTTCTTGAGCGTCCTCCCGGTACTCCCTTCGTCGCCGCCCTCCAGGGACCTCGGCACTCAGAAGACCGGCACCTCGTTCACCTGGTCCACCACATCAACCGCCGATACCATCTGTGGGCCTGACCTCCAAGGACAGCACTGGTGCCATTGCCCAGAGCGCAGGCAATTCACATCACAGGCCGGCCTTCCTCCTGCATTGGTGAATCCAGTTCCTCACCGCCGCGGTTCGTCGGTTTCGACGAGTGCCACGACACGTCGCAGGTACATAACATCCTCTTCTTGCAATCGTCTGGCCGGCCGCAACCACGTCATCTGCCCTCGAAAGCGTGCTTCAGCGTCCAGTGGACCACTTCTTCAGCTGCATGATTCGGGTAGCTCCTCTGCTCCAAGACTGGCCTTCCAGTACCTCGCCTTTTTGCCAGCCCAGCTCCTCTGGCAGCGGCTTCGTCGAGCTAATCTCTGCCCCGGCTTCACGCAACCGGCCGTCCACTGCGGGTGTCGCCGCCGTCGCCCGCCGCCGTTTTCGCATGCCGGATAAGCGGTGCAAGTTTGTGAAAGGTTGGATGGTCTCTTGGTTGCGTCCACACCCATCCCCATGCCGCTCTTTGTTTCCGTTTCTTTCCTGCTCGCCCCCGAATAAATCCCAAACGACCATTTTTTCACACATGCCGCTTTTAACAGCCGCCTTGCCCATCGCTCGCTCCTGCGGTTTACACCAACCCTCCAACACGTAGTGTCTCCGCTCTTCTGCAAGTAAATATATCCATTAATAACCTCCCGTTTTTGATTCCGTACCTTTCCTCAATACTCAAGTCAACACTTTCTTCTACCTCAGAGGTCTGTTGCCTGAAGTGACACTTCCGTTTATCTGCTCCTTGCTTCAAAACCTTGTTGCGCTTCGATCTTGGCTTCATCCTCCCGCCCCTGAGACGTGTAATGTAGCGCTTCCACCGTGTGTACAGACGATTAACTTCCACTATCCCAACGACTATCGAGGTTCTTTTTT
>m111101_034754_sidney_c100204702550000001519082301271281_s1_p0/80268/47_1236
CGGGCAGTCCATCACTGCTAGGCACCCACTTCGTTTCCCTTTTCCCACGTCTTGTCCATCCCTTCCAAACGACGATGAATCTGGTGTTTGTTTCCATCGCGTCCTGTGTTTACCTCGCGGCTGGCGGTCCTTGGCCCAGTCCTCTCCCAGATCAACACGCCCGCCAGCCGGCTGTGAGTGCCAACCGACTCTCCTCTCCTGGAGCCGGTGGAACCCCCCCGTACTTTCTTGAGCGTCCTCCCCGGTAACTTCGCCTTTCGCGGTCGCCCGCCCTCCAGGACTCGGACTTCAAGGACCGGCAAACCTCGTTCCCACCTGGCCACCAACATCACCGCCCGATACCTCTGTTGGCTGACCTCAAGACAGCACTGGTGCCATTGCCCAGAGCGCGGCAATTCACCGATTCCAGAGCCGGCCTCCTTCCTCTGCATTGGTGGATCAGTTCCTCCACCCGCCGCGGGTTTTTCGTCAGGTTCGACGAGTGGCCACGACGTCGGCAGTACTACATCCTCCTTCCTTCATCAGTCTGCGGCCGCACACGGTCATCCTGGCCTTGAAAGCGTCCTTCCAGCCCGTCCAAGTGACCACTTCCTTTCAGCCTGCCGGGATCGGGTAGCTCCTCTGCCTCCCAAAGATGGCTCCAGTACCTCCGCGCTGCCGCCAGCTCCTCTGGCAGCGCTTCGTCGAGAGTTTGCGGCTTTCACCACACGGCGTCAACCTACGCGTGTCCGCCGCCGTCGCGCCCGCCGTTTTCCGCCATGCTCGGATAAGCGTTGCATGTTTTGAAAAGGGTGGATGGTTTCGGTTGGTGCGTCCACACGCCTCCATCCGGCTCTTTGTTCGTTTCTTTCTGTTGCCTCCGATAATCAAACGACATTTTTTCACAACAATGCGGCTTTTTACAGCCGCTTGCCCTTCCGCTCGCTCCTCGCGGTTAACTCACCCCTCACACGTAGTGTCTCCGCTCTCGCAGTAATTATCCATTAATACCTGGCGTTTTGATTGTACTTTTCTCAATACGCAAAGTCAATTTTTTACTCACGACAGTCTGTTTGCTAGTGACACTTCCTTTATCTGGGCTCTGCTTCACCTTGTTGCGCCTTTCGATCTTGGATTCATCCCTTCGCCGCCTGGGAGGACGTTGTATGTTAGCGCTTCACCGTGGGTAGCAGACGATTACTTTCACGAT
>m111101_021445_sidney_c100204702550000001519082301271280_s1_p0/66923/35_1289
GGCAAGTCATCACTCTAATGCACCCACTTCGTTCCTTTTCCCACGCCCTTGCTCATCCCCTTCCAACGACCCGATGAAGTCTGTGGTTTGCTTTCCCTCGGCGTTTCCTGTGTCTCTTCGCGGCTTTGGGCGTCCTGGCCGTCTCTCAGATCAACACGCCGCGGCCGGCAGCGCTGTTGAGTTGGCCAACCGACCCTCTCCTCTTCCTGGAACACGGTTGGAACCCCCCCCGTACTTCCCTTGAGCCGTCTCCCGGTAACTCGCTTCCGTCCCCGCCCGCCCCTCCCAGGAACTCGGCACTCAGACGGCACCTCGTTCACCTGGTCCACCCCAACATCACCGGCCCGGATTACCATCTGTTGGCTGACCTCAGGACAGCATGGTGCCATTGCCCAGAGCGAGCATTCACGATCAGGCCCGGCCTTCTTCCTCCTGCATTGGTGGATCCAGTTTCCTCCACCGCCGCGGGTTCCGTCAGGTTCGACGAGTGCCACGACCGTCGGCCCAGGTACTACAATCCTCTTCTTCATCGTCTGCGGCCGCAAACCCACAGTTCATCTGCCTCGAAAGCGTCCTTCAGCGTCAAGTGACCAACTTCTTCAGCTGCAGGACATCGTAGCTCCCTCCTGCCCTCCAAGGACTGCCTCCAGCTAAACCATCCCGTCCTCGCCGCCCAGCTTCCTCTGGCAGCGTTCGTCACAGCTCTGCCCGGCTTCACCACCGCGATTCAACTACGGTGTCCGCGCCGTCGCCGCCGCCCCGTTTTCGGCCATGTTCGGGTATAAGCCGGTTGCATGTTTTTTGAAAAGGTGGATGGTTCGTTGGTTGCGCTCCCACCACCTCCCATACCGCTCTTGTTCCGTTCTTTCTGCTCGCCCGTCGAATAATCAAACGGACCATTTTTCACACATGCGCTTTTCAGCCGCTGCCCTCGCTCGCTCTCCGGTCACTTCACCCTCAACACGTAGTGGTTCTCCGCTCGTCGCAAGTACATATATCCATTTTAAATAACATGCCGTTTCTGATCCGTACTTTCTCATACGCAGTCACAGCTTTCTTCTACCGCTCAGAGTCTGTTGCCTAGGTGACACTTCTTTATCTTGCCCTCCTTTGGCCTTCACCCTTTGGATGCGCTTCGAGTCCTTGGATCATCCTCCCCGCCTGGAGACGTTGTTATGTGCCGCTTCACCGTGGTGTACAGACCGATTACTTCACGATCCAACGACTATCGGAGGGTTCTTTTTTCTTTGGGTT
>m111101_034754_sidney_c100204702550000001519082301271281_s1_p0/60605/32_1183
GAGTCCATCCCAGCACCCATCCTTCGTTCCTTTTCCCCACGTCTTGCCTCACCTTCACGACCGAGAAGTCGTGTTTTGTTTCCCTTCCGCGTCTGTGTCCTCCTTCGCGGCTGGCGTCCGTGGCAGCCCCTCCAGATAAGACACGGGCCGGCGAGGCTGTTGAGTCGCCAACGACTCTCCCTCCTGGAGCGGTGACCCCCCTACGTCTTAGAGCGTCTCCCCGGTAACTCGCCTTCGTCGCCCGCCTCCAGGACCGTCGCACTCAACGGCACCATCCGTTCACCTGGTCACCAACATCACCGCCCGATACCTCTGTTGGCCTGGACCCTCAGGACCGAAACTGGCTGCCAATTGCCCAGGCCAGCTTCACGATCAGGAGCCCGGCCCCTCTTCCCTGCATGGTGGATCAGTTCCTCCACCGCGCCGCGGGGCTTCGTCAGGTTCGACGAGTGCACGACGTCGCCGGTAACTACATCTCTTTTCCTTCATCGTCTGCGGCCCAACCCGTACATCGCCCGAAAAGCGTCCTCAGCGGTCAGTGACCACTTCCTTCAGCGGCGGATCCGGGTAGCTCCTCTGCCTCCAAGACTGGCCCAGTACCTCCGGCCGCCGCCAGCCTCTGCAGCGCCTTCCGTCGAGCAGCGCCTGGCCGGCTTCACCAGGCGTCAACTACGGTTGGGTCGCAGCGTCCGCCGCCGTTTTCCCTGCTCGGATTAACGGTTGCTGTTTGAATGGATGGTTTCGGTTGGTGCGTCACACCTCCCCCATACCCCGCTCTTTGTTCGTTTCCTTTCTGCTCGCCCTCGATAATAAAACGACCATTTTTTCACACATGCGCTTTTACGCGTGCCCTCCTCGCTTCCTCCGGTACACTCAACCTCCACACGTAGGTCCTCGCTCTCGCAGTACATATATCCTTAAATACATGCGTTTTGAATTCGTACCTTTCCTCATACGAAGTCACACTTTCTTCTACCTCAAAGAGTCTTGTTGCCTAGTGTGACACTGTCTTTTACTGCTCTTGCTTCCACCTTGTTGCGCTTCGGATCTTGGATTCACCCTCCCCGCCCTGGAGAACGTTGTATTACGGCTTTCCACCGTGGTGACAGACGATTACTTCACGATCCCCAACGGACTATCGAGGTTCTTTT
>m120410_145549_42173_c100321752550000001523017209061267_s2_p0/64998/3889_5032
GGCAGTCCAATACTCTAGCCCCACTTTCGGTTTCCCATTTTCCCACGTCTTGCTCTCCGCTCAGCGCGATGAAGTCTGTGTTTGTTTCAGCCTTCGCGTCTGTGTCCCTCTTCGCGCTGGACGTCCTTGGCCAGTTCTTCCAGATCAACAAACGCCGGCGCGCGTTGAGTGCCACCGACTCTCTTCTCCTGGAGCGGTGGAACCCCCCTACTTCTTGAGGTCCTCCCCGTAACTCGCCTTCGTCGCTCGCCTCCAGGACCTCGACACTAACAGACAGACACTCGATTCAACACAATAAGGAATAACACACAAATCCCAAAAGACACACGATAAACCTCTGTTGACTAAACACACAAACAAAGGGCAGCACTGTGCCACTTGCCAGGCGTAGTCATTCACGACTCCAGGTCCGGCTCTTCCTCCTGCATTGAGTGGATCCAGTCCTCACCGCGCGGGTTCGTCATGTTCAGACGAGTGCCCGAGTCGGCAGTGACTACATCCTTCTTCTTATCGTCTGCGGCCGCGAACACGTCATCTGCCTCGAAGCGTCTTCAGGCAGTGCACTTTTCAGCGGCAGGATCGGTAGCTCCTTGCTCAAGATGCTCCGAGTTCTTCGGGCTGCCGCCAGCTCCTCTGGCAGCGCTTCGGCCGAGCGTCTCTGCCGGCCTACCCAACGGCGTCAATCTGTGTCGCCGCTGTCGCCGCGCCGTTTTCCCCAGCTCGATAAGCGGTTGCATGTTTTGAAAAGGTGGGGATGTTTCGTTGGTTGCGTCAGCACCCTCCCCATCCGCTCGTTTGTTCCGTTTCTTGTCTGGCTCGGCCTCGATAATCAACCGGACCATTTTTTTCCGCACATTCGCTTTTTCAGCCGCTACCTCGCTCGCTCCACGGTTTACACTAAAGAGAATAAACATATATCCATTATACTGCCGATTTTGATTCCAGTAATTCCTCAATACGCAGTCCAACTTTCTTCTACCTCAGAGTCTGTTGCCTAGTGACCACTTTTACTGTGCTCTTGCTTCACCTTGTTGCACATTACGATCTTGATTATCCCTACCGCCGGGGACGTTGTATGTAAGCGTTCGACCGTGGTGTACAGACGATACTTCCGATCCAACGAACATCGAAGGTATTCTTATT
"""

if __name__ == "__main__":
    sanity_check_sge(sanity_check_gcon())
    
