import os, sys, subprocess
import numpy as np
import iCEC
import miscBio
from Bio import SeqIO
#import quickSW

"""
This is not exactly *post*-ICE more but is for handling merging of clusters
after every round of ICE member swapping in the clusters
"""

def possible_merge(r, ece_penalty, ece_min_len):
    """
    Criteria:
    (1) identity >= 99% and same strand
    (2) check criteria for how much is allowed to differ on the 5' / 3' ends

    NOTE: 100 bp on 5' and 30 bp on 3' leniency is now HARD-CODED! should change later
    """
    if r.sID == r.qID: return False
    if r.identity < 99: return False
    if r.strand == '-': return False # intentional here to prevent disrupting future ICE runs
    # MORE lenient on 5' but NOT on 3'
    if (r.qLength - r.qEnd) > 30 or (r.sLength - r.sEnd) > 30: return False
    if r.qStart > 100 or r.sStart > 100: return False
    arr = np.array([(x=='*')*1 for x in r.alnStr])
    if iCEC.alignment_has_large_nonmatch(arr, ece_penalty, ece_min_len): return False
    return True

def do_icec_merge_nogcon(icec, r):
    """
    Merge (i, j) --> k
    Delay gcon till later (icec.changes)
    """
    i = int(r.qID.split('/')[0][1:])
    j = int(r.sID.split('/')[0][1:])
    if i == j:
        return None
    if i not in icec.uc or j not in icec.uc:
        print >> sys.stderr, "{0} or {1} no longer exist. quit.".format(i, j)
        return None
    else:
        print >> sys.stderr, "merging {0} and {1}".format(r.qID, r.sID)
        k = icec.make_new_cluster()
        icec.uc[k] = icec.uc[i] + icec.uc[j]
        icec.delete_cluster(i)
        icec.delete_cluster(j)
        icec.freeze_d([k])
        icec.changes.add(k)
        return k


def find_mergeable_consensus(fasta_filename, maxScore, ece_penalty, ece_min_len, nproc=12):
    """
    run self-blasr on input fasta (likely tmp.consensus.fa)
    and yield BLASRm5 record of mergeable clusters
    """
    out = fasta_filename + '.self.blasr'
    if os.path.exists(out): # clean out the blasr file from the last run
        os.remove(out)
    cmd = "blasr {i} {i} -bestn 10 -nCandidates 10 -maxScore {s} -minPctIdentity 99 -m 5 -nproc {cpu} > {o}".format(i=fasta_filename, o=out, s=maxScore, cpu=nproc)
    print >> sys.stderr, "CMD:", cmd
    assert subprocess.check_call(cmd, shell=True) == 0
    for r in miscBio.BLASRm5Reader(out):
        if possible_merge(r, ece_penalty, ece_min_len):
            yield r

# THIS FUNCTION should be obsolete now that I add ATGGGG in primer stripping
# but keep it just in case I need it
#def trim_RTprimer(fasta_filename):
#    f = open(fasta_filename+'.trimmed.fa', 'w')
#    for r in SeqIO.parse(open(fasta_filename),'fasta'):
#        seq = r.seq.tostring().upper()
#        m = quickSW.quickSW("ATGGGG", seq[:10])
#        i = m[5,:].argmax()
#        if i >= 4: f.write(">{0}/RT\n{1}\n".format(r.id, seq[(i+1):]))
#        else: f.write(">{0}/noRT\n{1}\n".format(r.id, seq))
#    f.close()
#    return f.name

