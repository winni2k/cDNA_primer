#!/usr/bin/env python
import quiver_consensus_jchin_way as sp
sp.convert_fofn_to_fasta('input.fofn', None, 'input.fasta.fofn', force_overwrite=True)
