from distutils.core import setup
from distutils.extension import Extension

setup(
		name = 'ICE',
        version = '1.1', 
        author_email='etseng@pacificbiosciences.com',
        author='Elizabeth Tseng',
        packages = ['Liztools'],
        package_dir = {'Liztools': 'Liztools_pbdagcon/src/Liztools'},
        py_modules = ['basQV','gcon_Liztools',\
            'get_noFL', 'iCEC', 'init_ICE', 'post_ICE', \
            'make_input_fasta_fofn', 'miscBio', \
            'pClique', \
            'post_quiver_pick_goodones', \
            'quiver_consensus_jchin_way', \
            'include_nonFL_reads', \
            'run_ICE', \
            'run_partial_uc', \
            'run_Quiver_postICE', \
            'utils3'],
        data_files=[('example', ['example/c1/g_consensus.fa', 'example/c1/in.fa'])]
)

