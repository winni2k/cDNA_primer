#!/usr/bin/env python
# ----------------------------------------------------
# in output/
# (1) make final.consensus.fa.sa
# (2) create directory output/map_noFL
# (3) run alignment of no-FL(partial) reads to ICE consensus <--qsub jobs
# (4) when all qsub jobs are done, combine results
# ----------------------------------------------------
import os, sys, subprocess, glob, time
from cPickle import *
from collections import defaultdict

from argparse import ArgumentParser
parser = ArgumentParser()
parser.add_argument("-d", "--noFL-dir", dest="noFL_dir", required=True, help="Directory containing all (and only) fasta files of non-FL reads")
parser.add_argument("-n", "--num-jobs", dest="num_jobs", type=int, default=10, help="Number of parallel jobs to submit (default: 10, set to 0 if SGE cluster not available")

args = parser.parse_args()

partial_dir = args.noFL_dir # directory containing fasta files from no-FL (could have many)
num_jobs = args.num_jobs # number of qsub jobs

partial_dir = os.path.abspath(partial_dir)
partial_files = glob.glob(os.path.join(partial_dir, '*.fa')) + \
        glob.glob(os.path.join(partial_dir, '*.fasta'))

num_jobs = min(len(partial_files), num_jobs)
if num_jobs == 0:
    n = len(partial_files)
else:
    n = len(partial_files) / num_jobs + (len(partial_files) % num_jobs > 0)

os.chdir('output')
if not os.path.exists('final.consensus.fa.sa'):
    cmd = "sawriter final.consensus.fa.sa final.consensus.fa -blt 8 -welter"
    assert subprocess.check_call(cmd, shell=True) == 0

if not os.path.exists('map_noFL'): 
    os.mkdir('map_noFL')
os.chdir('map_noFL')

if not os.path.exists('final.consensus.fa'):
    cmd = "ln -s ../final.consensus.fa ."
    assert subprocess.check_call(cmd, shell=True) == 0
if not os.path.exists('final.consensus.fa.sa'):
    cmd = "ln -s ../final.consensus.fa.sa ."
    assert subprocess.check_call(cmd, shell=True) == 0
if not os.path.exists('reads_of_insert.fofn'):
    cmd = "ln -s ../../reads_of_insert.fofn ."
    assert subprocess.check_call(cmd, shell=True) == 0 

cmd_handles = [open('cmd'+str(i), 'w') for i in xrange(num_jobs)]
for f in cmd_handles:
    f.write("#!/bin/bash\n")
    f.write(". {0}/bin/activate\n".format(os.environ['VIRTUAL_ENV']))

for i,file in enumerate(partial_files):
    if not os.path.exists(file):
        cmd = "ln -s {0} .".format(file)
        assert subprocess.check_call(cmd, shell=True) == 0 
    cmd = "python /home/UNIXHOME/etseng/GitHub/PB_ICE/include_nonFL_reads.py reads_of_insert.fofn {0} final.consensus.fa".format(os.path.basename(file))
    f = cmd_handles[i/n]
    f.write(cmd + '\n')
    
for f in cmd_handles:
    f.close()
    if args.num_jobs > 0:
        cmd = "qsub -cwd -S /bin/bash -pe smp 12 " + f.name
    else:
        cmd = "bash " + f.name
    assert subprocess.check_call(cmd, shell=True) == 0


# now wait for all jobs to be done
# when it is each fasta file should have a .partial_uc.pickle output
ending_condition = all(os.path.exists(os.path.basename(file)+'.partial_uc.pickle') for file in partial_files)
sleep_time = 10
while not ending_condition:
    sleep_time = min(600, sleep_time*2)
    print >> sys.stderr, "waiting for qsub jobs to finish. keep sleeping for {0} secs".format(sleep_time)
    time.sleep(sleep_time)
    ending_condition = all(os.path.exists(os.path.basename(file)+'.partial_uc.pickle') for file in partial_files)

# combine all the partial output
partial_uc = defaultdict(lambda: [])
nohit = set()
for file in partial_files:
    a=load(open(os.path.basename(file)+'.partial_uc.pickle'))
    nohit.update(a['nohit'])
    for k,v in a['partial_uc'].iteritems():partial_uc[k]+=v
    
partial_uc=dict(partial_uc)
with open('noFL.ALL.partial_uc.pickle','w') as f:
    dump({'nohit':nohit,'partial_uc':partial_uc},f)
