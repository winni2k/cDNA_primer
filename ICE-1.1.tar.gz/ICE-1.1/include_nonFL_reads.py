#!/usr/bin/env python
import os, subprocess, sys, time
import miscBio
import iCEC
import miscBio
from collections import defaultdict
from cPickle import *
from Bio import SeqIO

def main(input_fofn, input_fasta, ref_fasta):
    cmd = "blasr {i} {r} -bestn 5 -nproc 12 -m 5 -sa {r}.sa -maxScore -1000 -minPctIdentity 85 -out {i}.blasr".format(\
            i=input_fasta, r=ref_fasta)
    done_filename = input_fasta + '.BLASR.DONE'
    if not os.path.exists(done_filename): 
        f = open(input_fasta + '_test.sh', 'w')
        f.write("#!/bin/bash\n")
        f.write(cmd + '\n')
        f.write("touch " + done_filename + '\n')
        f.close()
        if subprocess.check_call("bash {0}_test.sh &".format(input_fasta), shell=True)!=0:
            print "qsub failed. abort!"
            sys.exit(-1)

    probqv = iCEC.ProbFromQV(input_fofn, input_fasta)
    sleep_time = 1
    while True:
        if os.path.exists(done_filename): break
        sleep_time  = max(60, sleep_time * 2)
        print "sleep for another", sleep_time
        time.sleep(sleep_time)


    iter=iCEC.blasr_against_ref(input_fasta+'.blasr', False, True, probqv.get_smoothed, ece_penalty=1, ece_min_len=10, same_strand_only=False)
    
    partial_uc = {}
    seen = set()
    for r in iter:
        # r[0] is qID, r[1] is cID
        if r[-1] is not None:
            if r[1] not in partial_uc: partial_uc[r[1]] = []
            partial_uc[r[1]].append(r[0])
            seen.add(r[0])

    nohit = set(r.id for r in SeqIO.parse(open(input_fasta),'fasta')).difference(seen)

    with open(input_fasta + '.partial_uc.pickle', 'w') as f:
        dump({'partial_uc':partial_uc, 'nohit':nohit}, f)

    os.remove(input_fasta+'.blasr')

if __name__ == "__main__": main(sys.argv[1], sys.argv[2], sys.argv[3])
    
    
