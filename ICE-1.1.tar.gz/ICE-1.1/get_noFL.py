#!/usr/bin/env python
import os, sys
from collections import defaultdict
from csv import DictReader
import miscBio
import subprocess
from argparse import ArgumentParser

parser = ArgumentParser()
parser.add_argument("-d", dest="hmmer_dir", default="outputCCS", help="hmmer output directory from running hmmer_wrapper.py, [default: outputCCS]")
parser.add_argument("-i", dest="input_fasta", default="reads_of_insert.fasta", help="Input file that was used to run hmmer_wrapper.py, [default: reads_of_insert.fasta]")

args = parser.parse_args()

if not os.path.exists(args.hmmer_dir):
    print >> sys.stderr, "Directory {0} does not exist! Please indicate the directory in which the hmmer_wrapper.py output directory was stored, it usually contains a file called hmmer.out".format(args.hmmer_dir)
    sys.exit(-1)
if not os.path.exists(args.input_fasta):
    print >> sys.stderr, "Fasta file {0} does not exist. Abort!".format(args.input_fasta)
    sys.exit(-1)

cmd = "hmmer_wrapper.py -d {d} -i {i} --output-anyway --change-seqid -o reads_of_insert.output_anyway_changeid.fa".format(d=args.hmmer_dir, i=args.input_fasta)
if subprocess.check_call(cmd, shell=True)!=0:
    print >> sys.stderr, "TROUBLE RUNNING COMMAND:", cmd
    sys.exit(-1)

reader=DictReader(open('reads_of_insert.output_anyway_changeid.fa.primer_info.txt'),delimiter='\t')
d=defaultdict(lambda: [])
for r in reader:
    d[r['ID'][:r['ID'].rfind('/')]].append(r)
    
reader=miscBio.FastaReader('reads_of_insert.output_anyway_changeid.fa')
g=(lambda lst: any((x['5seen']=='1' and x['3seen']=='1' and x['polyAseen']=='1') for x in lst))
f=open('reads_of_insert.output_anyway_changeid.fa.noFL.fa','w')
for v in d.itervalues():
    if g(v): continue
    for x in v:
        try:
            r = reader[x['ID']]
            f.write(">{0}\n{1}\n".format(r.id,r.seq))
        except:
            print >> sys.stderr, "ignore", x['ID']
        
f.close()

os.remove('reads_of_insert.output_anyway_changeid.fa') # remove this since unlikely I'll use it
