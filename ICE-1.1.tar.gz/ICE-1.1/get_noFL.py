#!/usr/bin/env python
import os, sys
from collections import defaultdict
from csv import DictReader
import miscBio
import subprocess


cmd = "hmmer_wrapper.py -d outputCCS -i reads_of_insert.fasta  --output-anyway --change-seqid -o reads_of_insert.output_anyway_changeid.fa"
if subprocess.check_call(cmd, shell=True)!=0:
    print >> sys.stderr, "TROUBLE RUNNING COMMAND:", cmd
    sys.exit(-1)

reader=DictReader(open('reads_of_insert.output_anyway_changeid.fa.primer_info.txt'),delimiter='\t')
d=defaultdict(lambda: [])
for r in reader:
    d[r['ID'][:r['ID'].rfind('/')]].append(r)
    
reader=miscBio.FastaReader('reads_of_insert.output_anyway_changeid.fa')
g=(lambda lst: any((x['5seen']=='1' and x['3seen']=='1' and x['polyAseen']=='1') for x in lst))
f=open('reads_of_insert.output_anyway_changeid.fa.noFL.fa','w')
for v in d.itervalues():
    if g(v): continue
    for x in v:
        try:
            r = reader[x['ID']]
            f.write(">{0}\n{1}\n".format(r.id,r.seq))
        except:
            print >> sys.stderr, "ignore", x['ID']
        
f.close()

os.remove('reads_of_insert.output_anyway_changeid.fa') # remove this since unlikely I'll use it
