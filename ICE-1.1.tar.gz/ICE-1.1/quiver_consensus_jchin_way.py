__author__ = 'lachesis'
import os, sys, subprocess, random
import h5py as h5
from collections import defaultdict
import numpy as np
from pbtools.pbh5tools.CmpH5Utils import copyAttributes
from pbcore.io import BasH5Reader
import miscBio
from Bio import SeqIO

"""
Following jchin's /home/UNIXHOME/jchin/depot_mp27/jchin/rset_quvier.py

Input: input.fasta.fofn (shared), per-cluster in.fa, per-cluster g_consensus.fa

-- input.fasta.fofn should be raw fasta files (pls2fasta -maskRegion) of input.fofn

Within each cluster:
1) create in.raw.fa based on input.fasta.fofn & in.fa, putting in raw (unrolled) fasta of each ZMW
2) blasr (1) to g_consensus.fa output as SAM --> convert to .cmp.h5 --> loadPulses --> call Quiver

This is faster than using regions.fofn because it still reads through the whole .bax.h5 files
"""
def is_blank_sam(samfile):
    """
    return True if the SAM file only has @xx header and NO alignment
    """
    with open(samfile) as f:
        for line in f:
            if not line.startswith('@'): return False
    return True

def concat_sam(samfiles, outsam_filename):
    """
    Header looks like:
    @HD     VN:1.3.1
    @SQ     SN:c31  LN:3104 M5:ef7d3f84dea9d9face43e6fd5b6336c4
    @RG     ID:2caa54eef6   PU:in.raw_with_partial.fa       SM:NO_CHIP_ID
    @PG     ID:BLASR        VN:1.3.1.126469 CL:blasr in.raw_with_partial.fa g_consensus.fa -nproc 12 -bestn 5 -nCandidates 10 -sam -out out.sam
    
    NOTE: check for M5 conflicts; manipulate them if it conflicts
    """
    f_sq = open(outsam_filename+'.sq', 'w')
    f_bd = open(outsam_filename+'.bd', 'w')

    rg_line = None
    pg_line = None
    
    md5_seen = set()
    
    h = open(samfiles[0])
    line = h.readline()
    assert line.startswith('@HD')
    f_sq.write(line)
    line = h.readline()
    assert line.startswith('@SQ')
    line = h.readline()
    assert line.startswith('@RG')
    rg_line = line # write at the end
    line = h.readline()
    assert line.startswith('@PG')
    pg_line = line # write at the end
    h.close()

    for file in samfiles:
        with open(file) as h:
            assert h.readline().startswith('@HD')
            line = h.readline()
            assert line.startswith('@SQ')
            # ------- check for MD5 conflicts ----------- #
            m5 = line.strip().split()[-1]
            assert m5.startswith("M5:")
            if m5 not in md5_seen:
                f_sq.write(line)
                md5_seen.add(m5)
            else:
                s = list(m5[3:])
                while True:
                    random.shuffle(s)
                    s = "".join(s)
                    if s not in md5_seen: break
                line = line[:line.find('M5:')] + 'M5:' + s + '\n'
                print >> sys.stderr, "MD5 conflict: change to {0}".format(s)
                md5_seen.add(s)
                f_sq.write(line)
            # ----- end MD5 checking and writing --------- #
            assert h.readline().startswith('@RG')
            assert h.readline().startswith('@PG')
            for line in h:
                f_bd.write(line)
    
    f_bd.close()
    f_sq.write(rg_line)
    f_sq.write(pg_line)
    f_sq.close()

    if subprocess.check_call("cat {0}.sq {0}.bd > {0}".format(outsam_filename), shell=True)!=0:
        raise Exception, "failed to concat! Abort"

    os.remove(f_sq.name)
    os.remove(f_bd.name)


def setup_quiver_for_batch(cids, refs):
    """
    NOTE: (1) skip clusters if identical sequences already exists in another cluster (rare, but happens)
          (2) skip clusters if the alignment is empty (also rare, but happens)
    """
    # concat the same files
    prefix = "./quivered/c{0}to{1}".format(cids[0], cids[-1])

    valid_sam_files = []
    valid_cids = []
    seqs_seen = {}
    for x in cids:
        fname = os.path.join('./tmp', 'c'+str(x),'out.sam')
        if not is_blank_sam(fname):
            seq = SeqIO.read(open(refs[x]), 'fasta').seq.tostring()
            if seq not in seqs_seen:
                valid_sam_files.append(fname)
                valid_cids.append(x)
                seqs_seen[seq] = x
            else:
                print >> sys.stderr, "ignoring {0} because identical sequence!".format(x)
        else:
            print >> sys.stderr, "ignoring {0} because no alignments!".format(x)

    concat_sam(valid_sam_files, prefix + '.sam')
    # concat the reference file
    os.system("cat " + " ".join(refs[x] for x in valid_cids) + " > {0}.ref.fa".format(prefix))
    # write the sh script for the conversion, loadPulses, and quiver
    with open(prefix + '.sh', 'w') as f:
        f.write("#!/bin/bash\n")
        f.write("samtoh5 {0}.sam {0}.ref.fa {0}.cmp.h5 -smrtTitle\n".format(prefix))
        f.write("gzip {0}.sam\n".format(prefix))
        f.write("loadPulses input.fofn {0}.cmp.h5 -byread -metrics QualityValue,InsertionQV,MergeQV,DeletionQV,DeletionTag,SubstitutionTag,SubstitutionQV\n".format(prefix))
        f.write("cmph5tools.py sort {0}.cmp.h5\n".format(prefix))
        f.write("samtools faidx {0}.ref.fa\n".format(prefix))
        f.write("quiver {0}.cmp.h5 -v -j2 -p P4-C2.AllQVsMergingByChannelModel -r {0}.ref.fa -o {0}.quivered.fq\n".format(prefix))
    return f.name


def convert_fofn_to_fasta(fofn_filename, region_filename, out_filename, force_overwrite=False, f_out=sys.stderr):
    """
    For each .bax.h5 file, create .bax.h5.fasta file
    out_filename should usually be 'input.fasta.fofn'
    """
    f = open(out_filename, 'w')
    if region_filename is not None:
        g = open(region_filename)
    with open(fofn_filename) as h:
        for line in h:
            file = line.strip()
            assert file.endswith('.bax.h5') or file.endswith('.bas.h5')
            if region_filename is not None:
                rfile = g.readline().strip()
            else:
                print >> sys.stderr, "note: no region file used for", file
            tmp_out_file = file + '.fasta.tmp'
            out_file = file + '.fasta'
            if os.path.exists(out_file) and not force_overwrite:
                print >> sys.stderr, "{0} already exists. skipping.".format(out_file)
            else:
                cmd = "pls2fasta {0} {1} -minSubreadLength 500 -minReadScore 800 -trimByRegion".format(file, tmp_out_file)
                if region_filename is not None:
                    cmd += " -regionTable " + rfile
                f_out.write(cmd + '\n')
                subprocess.check_call(cmd, shell=True)
                trim_subread_flanks(tmp_out_file, out_file)
            f.write(out_file + '\n')
            os.remove(tmp_out_file)
    f.close()

def trim_subread_flanks(fasta_filename, output_filename, trim_len=100, min_len=300):
    """
    fasta_filename --- should be subread output from pls2fasta
    
    trim first/last 100bp (which contains primer&polyA) away and correct coordinates
    """
    with open(output_filename, 'w') as f:
        for r in SeqIO.parse(open(fasta_filename), 'fasta'):
            # ex: m140116_160800_42175_c100593482550000001823102205221476_s1_p0/15/1305_4354
            movie, hn, s_e = r.id.split('/')
            s, e = map(int, s_e.split('_'))
            assert s < e
            s2 = s + trim_len
            e2 = e - trim_len
            if e2 - s2 >= min_len:
                r.id = "{0}/{1}/{2}_{3}".format(movie, hn, s2, e2)
                r.description = ''
                r.seq = r.seq.tomutable()
                r.seq = r.seq[trim_len:-trim_len]
                SeqIO.write(r, f, "fasta")
                

def mask_adapter_region(bash5_filename, fasta_filename, output_filename):
    bas = BasH5Reader(bash5_filename)
    reader = SeqIO.parse(open(fasta_filename), 'fasta')
    with open(output_filename, 'w') as f:
        for r in reader:
            zmw = int(r.id.split('/')[-1])
            x = bas[zmw]
            r.seq=r.seq.tomutable()

            r_len = len(r.seq)
            if len(x.insertRegions) == 0: continue
            e = min(r_len, x.insertRegions[0][0]+100)
            r.seq[:e] = 'N'*e
            for i in xrange(1, len(x.insertRegions)):
                s = max(0, x.insertRegions[i-1][1]-100)
                e = min(r_len, x.insertRegions[i][0]+100)
                r.seq[s:e] = 'N'*(e-s)
            s = max(0, x.insertRegions[-1][1]-100)
            r.seq[s:] = 'N'*(r_len-s)
            SeqIO.write(r, f, 'fasta')

def write_in_raw_fasta(input_fasta_d, in_seqids, out_fa, ignore_keyerror=False):
    """
    input_fasta_d --- miscBio.MetaFastaReader
    in_fa --- input fasta should be in format <movie>/<holeNumber>/<subread or CCS stuff>

    Create a out_fa fasta where we dump the "raw" (unrolled) of every ZMW from in_fa
    """
    movies = set()
    zmw_seen = set()
    with open(out_fa, 'w') as f:
        #for r in SeqIO.parse(open(in_fa), 'fasta'):
        for seqid in in_seqids:
            try:
                zmw = seqid[:seqid.rfind('/')]
                if zmw not in zmw_seen:
                    movies.add(zmw.split('/')[0])
                    for rec in input_fasta_d[zmw]:
                        f.write(">{0}\n{1}\n".format(rec.id, rec.seq))
                    #f.write(">{0}\n{1}\n".format(zmw, input_fasta_d[zmw].seq))
                    zmw_seen.add(zmw)
            except KeyError:
                if ignore_keyerror:
                    print >> sys.stderr, "Ignorning non-existent key", zmw
                else:
                    raise Exception, "{0} doesn't exist. Abort!".format(zmw)
    return movies

def get_quiver_consensus(input_fofn, ref_fasta, input_fasta, output_dir=None, out_sam_filename='out.sam', movies=None, run_cmd=True):
    """
    input_fofn --- should be input.fofn
    input_fasta --- should be in.raw.fa
    ref_fasta --- reference fasta (ex: g_consensus.fa) to align to
    output_dir --- if None, automatically set to where ref_fasta is

    (1) run blasr to get sam
    (2) convert sam to .cmp.h5
    (3) loadPulses
    (4) sort cmp.h5
    (5) call quiver
    """
    if output_dir is None:
        output_dir = os.path.dirname(ref_fasta)

    if movies is not None:
        f = open(input_fasta + '.fofn', 'w')
        for line in open(input_fofn):
            if os.path.basename(line).split('.')[0] in movies:
                f.write(line)
        f.close()
        input_fofn = f.name
    out_sam = os.path.join(output_dir, out_sam_filename)
    #out_cmp = os.path.join(output_dir, 'out.cmp.h5')

    cmd = "blasr {i} {r} -nproc 12 -bestn 5 -nCandidates 10 -sam -clipping soft -out {o}".format(i=input_fasta, r=ref_fasta, o=out_sam)
    print >> sys.stderr, "CMD:", cmd
    if run_cmd: subprocess.check_call(cmd, shell=True)
    return cmd

#    cmd = "samtoh5 {s} {r} {o}".format(s=out_sam, r=ref_fasta, o=out_cmp)
#    print >> sys.stderr, "CMD:", cmd
#    subprocess.check_call(cmd, shell=True)
#
#    cmd = "loadPulses {i} {o} -byread -metrics QualityValue," \
#    "InsertionQV,MergeQV,DeletionQV,DeletionTag,SubstitutionTag,SubstitutionQV".format(i=input_fofn, o=out_cmp)
#    print >> sys.stderr, "CMD:", cmd
#    subprocess.check_call(cmd, shell=True)
#
#    cmd = "cmph5tools.py sort --inPlace " + out_cmp
#    print >> sys.stderr, "CMD:", cmd
#    subprocess.check_call(cmd, shell=True)
#
#    cmd = "quiver -p P4-C2.AllQVsMergingByChannelModel -j8 {o} -r {r} -o {o}.quivered.fq".format(o=out_cmp, r=ref_fasta)
#    print >> sys.stderr, "CMD:", cmd
#    subprocess.check_call(cmd, shell=True)


if __name__ == "__main__":
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument("--input_fofn", default='input.fofn')
    parser.add_argument("--ref_fasta", required=True)
    parser.add_argument("--input_fasta")
    parser.add_argument("--output_dir")

    args = parser.parse_args()

    get_quiver_consensus(args.input_fofn, args.ref_fasta, args.input_fasta, args.output_dir)

