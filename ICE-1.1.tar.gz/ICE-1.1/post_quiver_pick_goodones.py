#!/usr/bin/env python
import os, sys
from Bio import SeqIO
import post_ICE
import fnmatch
from cPickle import *

# --------- parameters ----------------------
partial_pickle_name = 'noFL.ALL.partial_uc.pickle'
qv_trim_5 = 100    # ignore first 100 bp on 5' end...Quiver usually can't call it very well + less coverage
qv_trim_3 = 30     # ignore last 30 bp on the 3' end, same reason
qv_max_err = 10    # total number of allowed expected base errors within seq[qv_trim_5:seq_trim_3]
output_prefix = sys.argv[1] # ex: i1, i2, i3  used when the input cells are divided up into different bins
# -------------------------------------------

files=fnmatch.filter(os.listdir('quivered/'), '*quivered.fq')
a=load(open('./output/final.pickle'))
uc=a['uc']
quivered={}

for file in files:
    for r in SeqIO.parse(open(os.path.join('quivered/',file)),'fastq'):
        cid = r.id.split('|')[0]
        if cid.endswith('_ref'): cid = cid[:-4]
        cid = int(cid[1:])
        quivered[cid] = r

for k in uc:
    if len(uc[k]) > 1: assert k in quivered       

good=[]

for cid,r in quivered.iteritems():
    q=[10**-(x/10.) for x in r.letter_annotations['phred_quality']]
    if sum(q[qv_trim_5:-qv_trim_3])<=qv_max_err: good.append(cid)
    
partial_uc=load(open('output/map_noFL/' + partial_pickle_name))['partial_uc']
from collections import defaultdict
partial_uc2=defaultdict(lambda: [])
partial_uc2.update(partial_uc)
f1=open('all_quivered.QV'+str(qv_max_err)+'_'+str(qv_trim_5)+'_'+str(qv_trim_3)+'.fa', 'w')
f1q=open('all_quivered.QV'+str(qv_max_err)+'_'+str(qv_trim_5)+'_'+str(qv_trim_3)+'.fq', 'w')
f2=open('all_quivered.bad.fa', 'w')
f2q=open('all_quivered.bad.fq', 'w')

for cid in quivered:
    if cid in good: f,fq=f1,f1q
    else: f,fq=f2,f2q
    r = quivered[cid]
    r.id = "{0}_c{1}/f{2}p{3}/{4}".format(output_prefix, cid, len(uc[cid]), len(partial_uc2[cid]), len(r.seq))
    f.write(">{0}\n{1}\n".format(r.id, r.seq))
    SeqIO.write(r, fq, "fastq")

f1.close()
f2.close()
f1q.close()
f2q.close()
