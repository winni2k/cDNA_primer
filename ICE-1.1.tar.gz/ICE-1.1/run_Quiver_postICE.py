#!/usr/bin/env python
import os, sys
from Bio import SeqIO
from cPickle import *
from collections import defaultdict
import quiver_consensus_jchin_way as sp
import miscBio
import time
from argparse import ArgumentParser

def submit_jobs(d, uc, partial_uc, refs, keys, start, end, homedir, submitted, todo, num_jobs):
    for i in xrange(start, end-99, 100):
        for k in keys[i:min(end,i+100)]:
            os.chdir('./tmp/c' + str(k))
            movies = sp.write_in_raw_fasta(d, uc[k]+partial_uc2[k], 'in.raw_with_partial.fa', True)
            sp.get_quiver_consensus('../../input.fofn', os.path.basename(refs[k]), 'in.raw_with_partial.fa', movies=movies)
            os.chdir(homedir)
        fname = sp.setup_quiver_for_batch(keys[i:min(end,i+100)], refs)
        todo.append(fname)
        if num_jobs == 0: # don't use SGE
            for x in todo: os.system("bash " + x)
            submitted += todo
            todo = []
        else:
            N = num_jobs - os.popen("qstat").read().count("\n")
            while len(todo) > 0 and N <= 0:
                print >> sys.stderr, "Cluster busy. Sleep for 60 secs."
                time.sleep(60)
            if N > 0 and len(todo) > 0:
                n = max(1, min(N, len(todo)))
                for x in todo[:n]: os.system("qsub -cwd -S /bin/bash -pe smp 2 {0}".format(x))
                submitted+=todo[:n]
                todo=todo[n:]


parser = ArgumentParser()
parser.add_argument("-n", "--num-jobs", dest="num_jobs", type=int, default=50, help="Max number of SGE jobs at a time. Set to 0 if SGE cluster not available")
args = parser.parse_args()

num_jobs = args.num_jobs


fasta_fofn = 'input.fasta.fofn'

homedir = os.path.abspath(os.getcwd())
if not os.path.exists('quivered'): os.mkdir('quivered')

files=[line.strip() for line in open(fasta_fofn)]
d=miscBio.MetaSubreadFastaReader(files)
a=load(open('./output/final.pickle'))
uc=a['uc']
refs=a['refs']
partial_uc=load(open('output/map_noFL/noFL.ALL.partial_uc.pickle'))['partial_uc']
partial_uc2=defaultdict(lambda: [])
partial_uc2.update(partial_uc)
keys=uc.keys()
good=filter(lambda x: len(uc[x])>1 or len(partial_uc2[x])>=10, uc)
keys=good
start=0
end=len(keys)

submitted=[]
todo=[]

submit_jobs(d, uc, partial_uc, refs, keys, start, end, homedir, submitted, todo, num_jobs)

