import os, sys
import numpy as np
from scipy.sparse import lil_matrix
from pbcore.io import BasH5Reader
from Bio.Seq import Seq
from collections import defaultdict

class h5_wrapper:
    """
    Wrap the .1.ccs.h5, .2.ccs.h5, .3.ccs.h5 to give the illusion of one
    (like what .bas.h5 does for .bax.h5)
    """
    def __init__(self, file_prefix, suffix='.ccs.h5'):
        """
        Expects <prefix>.1.ccs.h5, .2.ccs.h5, and .3.ccs.h5
        or .1.bax.h5, .2.bax.h5, .3.bax.h5
        """
        assert suffix in ('.ccs.h5', '.bax.h5')
        self.files = [file_prefix+'.1'+suffix, file_prefix+'.2'+suffix, file_prefix+'.3'+suffix]
        assert all(os.path.exists(file) for file in self.files)

        self.hn_range = [(0,54493),(54494,108987),(108988,170000)]
        #self.get_hn_range()

    def get_hn_range(self):
        for file in self.files:
            print >> sys.stderr, "getting holeNumber range for", file
            bas = BasH5Reader(file)
            _lo = bas.sequencingZmws[0]
            _hi = bas.sequencingZmws[-1]
            self.hn_range.append((_lo, _hi))

    def __getitem__(self, seqid):
        if seqid.count('/') == 1: hn = int(seqid.split('/')[1])
        elif seqid.count('/') == 2: hn = int(seqid.split('/')[1])
        else: raise Exception, "Cannot recognize", seqid
        for i in xrange(3):
            if self.hn_range[i][0] <= hn <= self.hn_range[i][1]: return self.files[i]
        raise Exception, "Unlocated holeNumber", hn


class basQVcacher:
    qv_names = ['InsertionQV', 'SubstitutionQV', 'DeletionQV']
    def __init__(self):
        self.bas_dict = {}
        self.bas_files = {}
        self.qv = {} # subread seqid --> qv_name --> list of qv (transformed to prob)
        self.window_size = None # smoothing window size, set when presmooth() is called

    def get(self, seqid, qv_type, position=None):
        if position is None:
            return self.qv[seqid][qv_type]
        else:
            return self.qv[seqid][qv_type][position]

    def get_smoothed(self, seqid, qv_type, position=None):
        if position is None:
            return self.qv[seqid][qv_type+'_smoothed']
        else:
            return self.qv[seqid][qv_type+'_smoothed'][position]

    def add_bash5(self, bash5_filename):
        basename = os.path.basename(bash5_filename)        
        if bash5_filename.endswith('.bax.h5'):
            movie = basename[:-9]
            if movie not in self.bas_files:
                self.bas_files[movie] = h5_wrapper(bash5_filename[:-9], suffix='.bax.h5')
        elif bash5_filename.endswith('.1.ccs.h5') or bash5_filename.endswith('.2.ccs.h5') or bash5_filename.endswith('.3.ccs.h5'):
            movie = basename[:-9]
            if movie not in self.bas_files:
                self.bas_files[movie] = h5_wrapper(bash5_filename[:-9])
        elif bash5_filename.endswith('.ccs.h5'): # a single .ccs.h5 (post 150k runs), treat the same as .bas.h5
            movie = basename[:-7]
            self.bas_files[movie] = defaultdict(lambda: bash5_filename)
        else:
            assert bash5_filename.endswith('.bas.h5') 
            movie = basename[:-7]
            self.bas_files[movie] = defaultdict(lambda: bash5_filename)

    def precache(self, seqids, fasta_d=None):
        """
        If fasta_d is given, is used to sanity-check that the extracted QVs are correct
        (by checking that the extracted sequence agrees with the fasta sequence)
        """
        # for subread ex: m120407_063017_42141_c100320212550000001523017409061204_s1_p0/13/2571_3282
        # for CCS ex:  m120407_063017_42141_c100320212550000001523017409061204_s1_p0/13/300_10_CCS
        
        # sort seqids by movie to save time
        seqids.sort(key=lambda x: (x.split('/')[0],int(x.split('/')[1])))
        
        last_bas_file = None
        for seqid in seqids:
            print >> sys.stderr, "precaching", seqid
            movie, hn, s_e = seqid.split('/')
            hn = int(hn)
            if s_e.endswith('_CCS'):
                is_CCS = True
                s, e = map(int, s_e.split('_')[:2])
            else:
                is_CCS = False
                s, e = map(int, s_e.split('_'))
            if s < e:
                strand = '+'
            else:
                s, e = e, s
                strand = '-'

            cur_bas_file = self.bas_files[movie][seqid]
            if cur_bas_file != last_bas_file:
                print >> sys.stderr, "lazy loading of movie file", cur_bas_file
                bas = BasH5Reader(cur_bas_file)
                last_bas_file = cur_bas_file
#                self.bas_dict[movie] = BasH5Reader(cur_bas_file)
#                if last_movie!=movie and last_movie is not None:
#                    del self.bas_dict[last_movie]
#            bas = self.bas_dict[movie]
#            last_movie = movie
            self.qv[seqid] = {}
            for qv_name in basQVcacher.qv_names:
                zmw = bas[hn]
                if is_CCS:
                    if zmw.ccsRead is not None:
                        qvs = zmw.ccsRead.qv(qv_name)[s:e]
                    else: # this is for reads_of_insert w/ 0-passed
                        qvs = zmw.read(s, e).qv(qv_name)
                else: # subread
                    qvs = zmw.read(s, e).qv(qv_name)
                if strand == '-':
                    qvs = qvs[::-1] 
                self.qv[seqid][qv_name] = np.array([10**-(qv/10.) for qv in qvs])
                #assert all(self.qv[seqid][qv_name] <= 1) and all(self.qv[seqid][qv_name] >= 0)
            
            if fasta_d is not None:
                if is_CCS: seq_from_bash5 = zmw.ccsRead.basecalls()[s:e]
                else: seq_from_bash5 = zmw.read(s, e).basecalls()
                if strand == '-':
                    seq_from_bash5 = Seq(seq_from_bash5).reverse_complement().tostring()
                assert seq_from_bash5 == fasta_d[seqid].seq.tostring()

        # cleaning out self.bas_dict
        self.bas_dict = {}

    def presmooth(self, seqids, window_size):
        """
        precache MUST BE already called! Otherwise will have error!
        """
        self.window_size = window_size
        for seqid in seqids:
            print >> sys.stderr, "smoothing sequence", seqid
            self.smooth_qv_regions(seqid, window_size)

    def smooth_qv_regions(self, seqid, window_size):
        """
        Added <qv_name>_smoothed tracks where

        QV[i] = max(QV[i-window_size/2:i+window_size/2)
        (the window_size should be odd)
        """
        n = window_size / 2
        for qv_name in basQVcacher.qv_names:
            tmp = self.qv[seqid][qv_name]
            self.qv[seqid][qv_name+'_smoothed'] = [tmp[max(0,i-n):i+n].max() for i in xrange(len(tmp))]

    def remove_unsmoothed(self):
        for k,v in self.qv.iteritems():
            for qv_name in basQVcacher.qv_names:
                try:
                    del self.qv[k][qv_name]
                except KeyError:
                    pass # may have already been deleted. OK.
                
                
class basQVcacherSparse(basQVcacher):
    def __init__(self, prob_threshold, window_size):
        self.bas_dict = {}
        self.bas_files = {}
        self.qv = {} # subread seqid --> qv_name --> list of qv (transformed to prob)
        self.prob_threshold = prob_threshold
        self.window_size = window_size
            
    def get(self, seqid, qv_type, position=None):
        if position is None:
            return self.qv[seqid][qv_type][0, :].toarray()[0]
        else:
            return self.qv[seqid][qv_type][0, position]
        
    def get_smoothed(self, seqid, qv_type, position):
        """
        QV[i] = max(QV[i-window_size/2:i+window_size/2)
        (the window_size should be odd)
        """
        if position is None:
            raise Exception, "Currently not implemented! Abort!"
        else:
            i = max(0, position - self.window_size/2)
            j = min(position + self.window_size/2 + 1, self.qv[seqid][qv_type].shape[1])
            if self.qv[seqid][qv_type][0, i:j].nnz == 0: # all zeros 
                return 0.
            else:
                return max(max(self.qv[seqid][qv_type][0, i:j].data))            
        
    def precache(self, seqids, fasta_d=None):
        """
        If fasta_d is given, is used to sanity-check that the extracted QVs are correct
        (by checking that the extracted sequence agrees with the fasta sequence)
        
        self.prob_threshold --- prob above this considered likely erroneous (so store in array)
         
        """
        # for subread ex: m120407_063017_42141_c100320212550000001523017409061204_s1_p0/13/2571_3282
        # for CCS ex:  m120407_063017_42141_c100320212550000001523017409061204_s1_p0/13/300_10_CCS
        
        # sort seqids by movie to save time
        seqids.sort(key=lambda x: x[:x.find('/')])
        
        last_movie = None
        for seqid in seqids:
            print >> sys.stderr, "precaching", seqid
            movie, hn, s_e = seqid.split('/')
            hn = int(hn)
            if s_e.endswith('_CCS'):
                is_CCS = True
                s, e = map(int, s_e.split('_')[:2])
            else:
                is_CCS = False
                s, e = map(int, s_e.split('_'))
            if s < e:
                strand = '+'
            else:
                s, e = e, s
                strand = '-'
            if movie not in self.bas_dict:
                print >> sys.stderr, "lazy loading of movie file", self.bas_files[movie]
                self.bas_dict[movie] = BasH5Reader(self.bas_files[movie])
                if last_movie!=movie and last_movie is not None:
                    del self.bas_dict[last_movie]
            bas = self.bas_dict[movie]
            last_movie = movie
            self.qv[seqid] = {}
            for qv_name in basQVcacher.qv_names:
                zmw = bas[hn]
                if is_CCS:
                    qvs = zmw.ccsRead.qv(qv_name)[s:e]
                else: # subread
                    qvs = zmw.read(s, e).qv(qv_name)
                if strand == '-':
                    qvs = qvs[::-1] 
                # --------------------------------------------------------------
                # use self.prob_threshold to determine whether or not to store
                # store it is 1 - prob[prob >= self.prob_threshold]
                # --------------------------------------------------------------
                x = np.array([10**-(qv/10.) for qv in qvs])
                x[x <= self.prob_threshold] = 0            
                self.qv[seqid][qv_name] = lil_matrix(x)
            
            if fasta_d is not None:
                if is_CCS: seq_from_bash5 = zmw.ccsRead.basecalls()[s:e]
                else: seq_from_bash5 = zmw.read(s, e).basecalls()
                if strand == '-':
                    seq_from_bash5 = Seq(seq_from_bash5).reverse_complement().tostring()
                assert seq_from_bash5 == fasta_d[seqid].seq.tostring()

        # cleaning out self.bas_dict
        self.bas_dict = {}    
            
# NOT USED FOR NOW since numpy's .max() should be tolerably fast and only has to be run once
# keep this for future possible use
def maxval_per_window(arr, window_size):
    from collections import deque
    q = deque()
    result = deque()

    i = arr[:window_size].argmax()
    q.append((i, arr[i]))
    result.append(arr[i])

    for i in xrange(1, len(arr)-window_size-1):
        # now looking at range [i, i+window_size)
        if q[0][0] < i: q.popleft()
        new_element = arr[i+window_size-1]
        if len(q) == 0:
            q.append((i+window_size-1, new_element))
        elif new_element >= q[0][1]:
            q.clear()
            q.append((i+window_size-1, new_element))
        else:
            while len(q) > 0:
                x = q.pop()
                if x[1] > new_element:
                    q.append(x)
                    break
            q.append((i+window_size-1, new_element))
        result.append(q[0][1])
        #assert q[0][1] == arr[i:i+window_size].max()

    return result
