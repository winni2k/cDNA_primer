__author__ = 'etseng@pacificbiosciences.com'

import os, sys, subprocess
import networkx as nx
import iCEC
from Bio import SeqIO
import pClique

"""
Only called once and in the very beginning of ICE when (probably a subset) of sequences are given
to generate the initial cluster

This is usually called from within iCEC
"""

def init_cluster_by_clique(fasta_filename, qver_get_func, bestn=100, ece_penalty=1, ece_min_len=20, nproc=8, maxScore=-1000):
    """
    fasta_filename --- initial fasta filename, probably called aloha.fa_split00.fa
    qver_get_func --- function that returns QVs on reads
    bestn --- parameter in BLASR, higher helps in finding perfect cliques but bigger output
    nproc, maxScore --- parameter in BLASR, set maxScore appropriate to input transcript length
    ece_penalty, ece_min_len --- parameter in isoform hit calling

    Self-blasr input then iteratively find all mutually exclusive cliques (in decreasing size)
    Returns dict of cluster_index --> list of seqids
    which is the 'uc' dict that can be used by ICE
    """
    out_filename = fasta_filename + '.self.blasr'

    if os.path.exists(out_filename):
        print >> sys.stderr, "{0} already exists. No need to run BLASR.".format(out_filename)
    else:
        cmd = "blasr {i} {i} -m 5 -maxLCPLength 15 -nproc {cpu} -maxScore {score} -bestn {n} -nCandidates {n} -out {o}".format(\
        i=fasta_filename, n=bestn, o=out_filename, cpu=nproc, score=maxScore)
        print >> sys.stderr, cmd
        subprocess.check_call(cmd, shell=True)

    G = nx.Graph()
    for r in iCEC.blasr_against_ref(out_filename, is_FL=True, sID_starts_with_c=False, qver_get_func=qver_get_func, ece_penalty=ece_penalty, ece_min_len=ece_min_len):
        if r[0] == r[1]: continue # self hit, ignore
        if r[-1] is not None:
            print >> sys.stderr, "adding edge {0},{1}".format(r[0], r[1])
            G.add_edge(r[0], r[1])

    uc = {}
    used = []
    ind = 0

    deg = G.degree().items()
    deg.sort(key=lambda x:x[1], reverse=True)
    for d in deg:
        if d[0] not in G: continue
        # just get the immediate neighbors since we're looking for perfect cliques
        G_prime = G.subgraph([d[0]] + G.neighbors(d[0]))
        G_prime_nodes = G_prime.nodes()
        S,H = pClique.convert_graph_connectivity_to_sparse(G_prime, G_prime_nodes)
        seed_i = G_prime_nodes.index(d[0])
        tQ = pClique.grasp(S, H, 1., 5, seed_i)
        if len(tQ) > 0:
            c = [G_prime_nodes[i] for i in tQ]
            uc[ind] = c
            ind += 1
            used += c
            G.remove_nodes_from(c)

# ------ below, old way of using find_cliques, inefficient on large graphs
#    cliques = list(nx.find_cliques(G))
#    cliques.sort(key=lambda x: len(x), reverse=True)
#    for c in cliques:
#        if all(map(lambda x: x in G, c)):
#            uc[ind] = c
#            ind += 1
#            used += c
#            G.remove_nodes_from(c)

    for r in SeqIO.parse(open(fasta_filename), 'fasta'):
        if r.id not in used:
            uc[ind] = [r.id]
            ind += 1

    return uc

