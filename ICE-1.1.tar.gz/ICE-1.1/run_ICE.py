#!/usr/bin/env python
from cPickle import *
import miscBio
import iCEC
import init_ICE
from Bio import SeqIO
import os, sys, fnmatch, subprocess


# ------------------------------------------------------------------------------
# BEGIN OF USER-DEFINED PARAMETERS
# ------------------------------------------------------------------------------
# recommended maxScore for each size bin:
# under1k: -1000
# 1-2k: -2000
# 2-3k: -3000
# >3k: -5000
maxScore  = -1000
job_random_offset = 100

# name of FOFN filename which is likely either 'input.fofn' and 'reads_of_insert.fofn'
# if does not have QV, set to None
fofn_filename='reads_of_insert.fofn'
# number of CPUs to use on this main core for BLASR
NPROC=24
# whether you have SGE cluster and plan to use it for not. If don't have, set to False
use_parallel=True
# number of parallel jobs to submit
NUM_JOBS=40
# ------------------------------------------------------------------------------
# END OF USER-DEFINED PARAMETERS
# ------------------------------------------------------------------------------

ece_penalty=1
ece_min_len=20


# checking necessary files
# - input.fa
# - reads_of_insert.fofn
if not os.path.exists('input.fa'):
    print >> sys.stderr, "Required input file input.fa does not exist. Abort."
    sys.exit(-1)
if fofn_filename is not None and not os.path.exists(fofn_filename):
    print >> sys.stderr, "Required input file {0} does not exist. Abort.".format(fofn_filename)
    sys.exit(-1)


# SPLIT THE FILES (20000-seq a chunk)
subprocess.check_call("split -l 40000 -d input.fa input.fa_split", shell=True)
files = fnmatch.filter(os.listdir('.'),'*split*')
for file in files: subprocess.check_call("mv {0} {0}.fa".format(file), shell=True)

if fofn_filename is None:
    probqv = iCEC.ProbFromModel(.01, .07, .06)
else:
    # load the QV and get the initial UC
    probqv = iCEC.ProbFromQV(fofn_filename, 'input.fa_split00.fa')
uc = init_ICE.init_cluster_by_clique('input.fa_split00.fa', probqv.get_smoothed, nproc=NPROC, maxScore=maxScore, ece_penalty=ece_penalty, ece_min_len=ece_min_len)
with open('init.uc.pickle', 'w') as f: dump(uc, f)
icec = iCEC.iCEC_iterative('input.fa_split00.fa', fofn_filename, 'input.fa', uc=uc, num_jobs=NUM_JOBS, probQV=probqv, use_parallel=use_parallel, maxScore=maxScore, job_random_offset=job_random_offset, ece_penalty=ece_penalty, ece_min_len=ece_min_len)
icec.run_til_end(5)
sizes = [len(icec.uc)]

files = fnmatch.filter(os.listdir('.'),'input.fa_split*.fa')
files.remove('input.fa_split00.fa')
files.sort()
iCEC.keep_adding_files(icec, sizes, files)
iCEC.run_post_ICE_merging(icec, 'output/tmp', 3)
icec.random_prob=0.01
for i in xrange(5):
    icec.run_for_new_batch()
    sizes.append(len(icec.uc))
    
icec.write_consensus('output/final.consensus.fa')
icec.write_pickle('output/final.pickle')
